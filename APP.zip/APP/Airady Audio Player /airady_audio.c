/*
 * AiradyTouch OS - Airady Audio v0.1
 * WAV音频播放器（PCM WAV）
 * 编译：gcc airady_audio.c -o airady_audio -lsndfile -lasound
 * 使用：./airady_audio play test.wav
 *       ./airady_audio info test.wav
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sndfile.h>
#include <alsa/asoundlib.h>

#define BUF_FRAMES 4096

static void show_info(const char *path)
{
    SF_INFO sfinfo;
    memset(&sfinfo, 0, sizeof(sfinfo));
    SNDFILE *sf = sf_open(path, SFM_READ, &sfinfo);
    if (!sf)
    {
        fprintf(stderr, "❌ 无法打开音频文件: %s\n", sf_strerror(NULL));
        return;
    }
    printf("==== 音频信息 ====\n");
    printf("文件名: %s\n", path);
    printf("采样率: %d Hz\n", (int)sfinfo.samplerate);
    printf("声道数: %d\n", (int)sfinfo.channels);
    printf("总帧数: %lld\n", sfinfo.frames);
    double sec = (double)sfinfo.frames / sfinfo.samplerate;
    printf("时长: %.2f 秒\n", sec);
    printf("==================\n");
    sf_close(sf);
}

static int play_wav(const char *path)
{
    SF_INFO sfinfo;
    memset(&sfinfo, 0, sizeof(sfinfo));
    SNDFILE *sf = sf_open(path, SFM_READ, &sfinfo);
    if (!sf)
    {
        fprintf(stderr, "❌ sf_open失败: %s\n", sf_strerror(NULL));
        return -1;
    }

    snd_pcm_t *pcm;
    int rc = snd_pcm_open(&pcm, "default", SND_PCM_STREAM_PLAYBACK, 0);
    if (rc < 0)
    {
        fprintf(stderr, "❌ ALSA打开设备失败: %s\n", snd_strerror(rc));
        sf_close(sf);
        return -1;
    }

    snd_pcm_hw_params_t *hwparams;
    snd_pcm_hw_params_alloca(&hwparams);
    snd_pcm_hw_params_any(pcm, hwparams);
    snd_pcm_hw_params_set_access(pcm, hwparams, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(pcm, hwparams, SND_PCM_FORMAT_S16_LE);
    snd_pcm_hw_params_set_channels(pcm, hwparams, sfinfo.channels);
    unsigned int rate = sfinfo.samplerate;
    snd_pcm_hw_params_set_rate_near(pcm, hwparams, &rate, NULL);
    snd_pcm_hw_params(pcm, hwparams);

    short buf[BUF_FRAMES * sfinfo.channels];
    sf_count_t readcnt;
    printf("▶️ 正在播放: %s\n", path);
    while ((readcnt = sf_readf_short(sf, buf, BUF_FRAMES)) > 0)
    {
        rc = snd_pcm_writei(pcm, buf, readcnt);
        if (rc < 0)
        {
            rc = snd_pcm_recover(pcm, rc, 0);
            if (rc < 0) break;
        }
    }
    snd_pcm_drain(pcm);
    snd_pcm_close(pcm);
    sf_close(sf);
    printf("✅ 播放结束\n");
    return 0;
}

static void help(void)
{
    printf("==== Airady Audio Player ====\n");
    printf("用法：\n");
    printf("  ./airady_audio play 音频.wav\n");
    printf("  ./airady_audio info 音频.wav\n");
    printf("仅支持 PCM WAV 文件\n");
}

int main(int argc, char **argv)
{
    if (argc < 3)
    {
        help();
        return 1;
    }
    if (strcmp(argv[1], "info") == 0)
    {
        show_info(argv[2]);
    }
    else if (strcmp(argv[1], "play") == 0)
    {
        play_wav(argv[2]);
    }
    else
    {
        help();
        return 1;
    }
    return 0;
}