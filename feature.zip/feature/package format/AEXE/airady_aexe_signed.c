/*
 * Airady AEXE with SHA256 Signature v0.2
 * 带签名校验 .aexe
 * 编译：gcc airady_aexe_signed.c -o airady_aexe -lcrypto
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <openssl/sha.h>

#define AEXE_MAGIC "AIRADYEXE"
#define MAGIC_LEN 9
#define NAME_MAX 64
#define VER_MAX 32
#define DESC_MAX 256
#define ICON_MAX 512
#define SIG_LEN SHA256_DIGEST_LENGTH

typedef struct {
    char magic[MAGIC_LEN];
    unsigned short fmt_ver;
    char name[NAME_MAX];
    char version[VER_MAX];
    char desc[DESC_MAX];
    char icon[ICON_MAX];
    long bin_size;
    char reserved[64];
} AexeHeader;

static long get_file_size(FILE *fp) {
    fseek(fp,0,SEEK_END);
    long sz = ftell(fp);
    fseek(fp,0,SEEK_SET);
    return sz;
}

static int calc_sha256(FILE *fp, unsigned char out_hash[SIG_LEN]) {
    fseek(fp,0,SEEK_SET);
    long total = get_file_size(fp);
    long data_len = total - SIG_LEN;
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    char buf[4096];
    long left = data_len, r;
    while(left>0 && (r=fread(buf,1,sizeof(buf),fp))>0) {
        if(r>left) r=left;
        SHA256_Update(&ctx, buf, r);
        left -= r;
    }
    SHA256_Final(out_hash, &ctx);
    return 0;
}

static int aexe_verify(const char *path) {
    FILE *fp = fopen(path, "rb");
    if(!fp) return -1;
    long fsz = get_file_size(fp);
    if(fsz <= SIG_LEN) { fclose(fp); return -1; }
    unsigned char calc_hash[SIG_LEN];
    calc_sha256(fp, calc_hash);
    unsigned char stored[SIG_LEN];
    fseek(fp, fsz - SIG_LEN, SEEK_SET);
    fread(stored,1,SIG_LEN,fp);
    fclose(fp);
    return memcmp(calc_hash, stored, SIG_LEN);
}

static int aexe_build(const char *bin_src, const char *out_path) {
    FILE *fin = fopen(bin_src, "rb");
    if(!fin) { perror("open bin"); return -1; }
    FILE *fout = fopen(out_path, "wb");
    if(!fout) { perror("create aexe"); fclose(fin); return -1; }

    AexeHeader hdr;
    memset(&hdr,0,sizeof(hdr));
    memcpy(hdr.magic, AEXE_MAGIC, MAGIC_LEN);
    hdr.fmt_ver = 1;
    printf("===== 构建 AEXE（带签名）=====\n");
    printf("程序名称："); scanf("%s", hdr.name);
    printf("版本号："); scanf("%s", hdr.version); getchar();
    printf("描述："); fgets(hdr.desc, DESC_MAX, stdin);
    hdr.desc[strcspn(hdr.desc,"\n")]=0;
    printf("ASCII图标："); fgets(hdr.icon, ICON_MAX, stdin);
    hdr.icon[strcspn(hdr.icon,"\n")]=0;

    long bsize = get_file_size(fin);
    hdr.bin_size = bsize;
    fwrite(&hdr, sizeof(AexeHeader),1,fout);
    char buf[4096]; long rd;
    while((rd=fread(buf,1,sizeof(buf),fin))>0) fwrite(buf,1,rd,fout);
    fclose(fin); fclose(fout);

    FILE *fp = fopen(out_path, "r+b");
    unsigned char hash[SIG_LEN];
    calc_sha256(fp, hash);
    fseek(fp,0,SEEK_END);
    fwrite(hash,1,SIG_LEN,fp);
    fclose(fp);
    chmod(out_path,0755);
    printf("✅ AEXE打包+签名成功：%s\n", out_path);
    return 0;
}

static int aexe_read_header(const char *path, AexeHeader *hdr) {
    if(aexe_verify(path) != 0) {
        printf("❌ AEXE签名校验失败，文件篡改\n");
        return -4;
    }
    FILE *fp = fopen(path, "rb");
    if(!fp) return -1;
    if(fread(hdr, sizeof(AexeHeader),1,fp)!=1) { fclose(fp); return -2; }
    if(memcmp(hdr->magic, AEXE_MAGIC, MAGIC_LEN)!=0) {
        printf("❌ 非法AEXE\n"); fclose(fp); return -3;
    }
    fclose(fp);
    return 0;
}

static int aexe_info(const char *path) {
    AexeHeader hdr;
    int ret = aexe_read_header(path, &hdr);
    if(ret !=0) return ret;
    printf("\n===== AEXE信息（校验通过）=====\n");
    printf("名称：%s\n版本：%s\n描述：%s\n图标：%s\n程序大小：%ld\n",
           hdr.name, hdr.version, hdr.desc, hdr.icon[0]?hdr.icon:"无", hdr.bin_size);
    return 0;
}

static int aexe_run(const char *path) {
    AexeHeader hdr;
    int ret = aexe_read_header(path, &hdr);
    if(ret !=0) return ret;
    FILE *fp = fopen(path, "rb");
    fseek(fp, sizeof(AexeHeader), SEEK_SET);
    char tmpname[] = "/tmp/airady_aexe_XXXXXX";
    int fd = mkstemp(tmpname);
    FILE *ftmp = fdopen(fd, "wb");
    char buf[4096]; long left = hdr.bin_size, r;
    while(left>0 && (r=fread(buf,1,sizeof(buf),fp))>0) {
        fwrite(buf,1,r,ftmp); left -= r;
    }
    fclose(ftmp); fclose(fp);
    chmod(tmpname,0755);
    printf("🚀 启动 %s\n", hdr.name);
    pid_t pid = fork();
    if(pid == 0) {
        execl(tmpname, tmpname, (char*)NULL);
        exit(127);
    }
    wait(NULL);
    unlink(tmpname);
    return 0;
}

static void help(void) {
    printf("Airady AEXE Signed SHA256 v0.2\n");
    printf("build / info / run / verify\n");
}

int main(int argc, char **argv) {
    if(argc <2) { help(); return1; }
    if(strcmp(argv[1],"build")==0) {
        if(argc<4) { printf("build bin out.aexe\n"); return1; }
        aexe_build(argv[2],argv[3]);
    } else if(strcmp(argv[1],"verify")==0) {
        if(aexe_verify(argv[2])==0) printf("✅ AEXE签名校验通过\n");
        else printf("❌ AEXE签名校验失败\n");
    } else if(strcmp(argv[1],"info")==0) {
        if(argc<3) return1; aexe_info(argv[2]);
    } else if(strcmp(argv[1],"run")==0) {
        if(argc<3) return1; aexe_run(argv[2]);
    } else { help(); return1; }
    return 0;
}