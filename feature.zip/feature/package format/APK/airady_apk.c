import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import java.util.Locale

object ApkSignVerify {

    // ========== 这里填你自己签名证书的 SHA256 指纹！！==========
    // 用 keytool -printcert -jarfile xxx.apk 算出
    private const val EXPECTED_SHA256 = "替换成你的证书SHA256"

    fun checkApkSignature(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            val pkgName = context.packageName
            val packageInfo: PackageInfo

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // Android9+ 新API，支持v2/v3签名
                packageInfo = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signingInfo = packageInfo.signingInfo ?: return false
                val signers = signingInfo.apkContentsSigners
                if (signers.isEmpty()) return false
                val certBytes = signers[0].toByteArray()
                val realSha256 = calcSha256(certBytes)
                realSha256.equals(EXPECTED_SHA256, ignoreCase = true)
            } else {
                // 旧版安卓 v1签名兼容
                packageInfo = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNATURES)
                val sigs = packageInfo.signatures
                if (sigs.isNullOrEmpty()) return false
                val certBytes = sigs[0].toByteArray()
                val realSha256 = calcSha256(certBytes)
                realSha256.equals(EXPECTED_SHA256, ignoreCase = true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // 计算SHA256指纹，转十六进制小写
    private fun calcSha256(data: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(data)
        return digest.joinToString("") { "%02x".format(it) }.lowercase(Locale.US)
    }
}