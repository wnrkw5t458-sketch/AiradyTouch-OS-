/*
 * AiradyTouch OS - Airady Package Installer v0.1
 * 包安装器：解析 MIK 和自研 AIRADY-EXE 包
 * 编译：gcc airady_pkg.c -o airady_pkg -lsqlite3
 * 使用示例：
 * ./airady_pkg install ./myapp.mik
 * ./airady_pkg install ./myapp.exe
 * ./airady_pkg list
 * ./airady_pkg remove myapp
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

#define DB_PATH "/var/airady/store.db"
#define MIK_MAGIC "AIRADY-MIK"
#define EXE_MAGIC "AIRADY-EXE"
#define MAGIC_LEN 10
#define MAX_PATH 512
#define BUF_SIZE 4096
#define SYS_INST_ROOT "/airady/apps"

typedef enum {
    PKG_NONE,
    PKG_MIK,
    PKG_AIRADY_EXE
} PkgType;

static int make_dir(const char *path)
{
    struct stat st;
    if (stat(path, &st) == 0 && S_ISDIR(st.st_mode))
        return 0;
    return mkdir(path, 0755);
}

static PkgType detect_pkg_type(FILE *fp)
{
    char magic[MAGIC_LEN + 1] = {0};
    fseek(fp, 0, SEEK_SET);
    size_t rd = fread(magic, 1, MAGIC_LEN, fp);
    if (rd < MAGIC_LEN)
        return PKG_NONE;
    if (memcmp(magic, MIK_MAGIC, MAGIC_LEN) == 0)
        return PKG_MIK;
    if (memcmp(magic, EXE_MAGIC, MAGIC_LEN) == 0)
        return PKG_AIRADY_EXE;
    return PKG_NONE;
}

static const char* pkgtype_str(PkgType t)
{
    switch(t) {
        case PKG_MIK: return "MIK";
        case PKG_AIRADY_EXE: return "EXE";
        default: return "UNKNOWN";
    }
}

static int extract_pkg(FILE *fp, const char *dest)
{
    make_dir(dest);
    // 跳过 magic + time_t 头部
    fseek(fp, MAGIC_LEN + sizeof(time_t), SEEK_SET);

    unsigned char buf[BUF_SIZE];
    size_t r;
    FILE *out;
    char outpath[MAX_PATH];
    snprintf(outpath, MAX_PATH, "%s/app.bin", dest);
    out = fopen(outpath, "wb");
    if (!out) {
        fprintf(stderr, "无法写入目标文件 %s\n", outpath);
        return -1;
    }
    while ((r = fread(buf, 1, BUF_SIZE, fp)) > 0) {
        fwrite(buf, 1, r, out);
    }
    fclose(out);
    printf("  包内容提取至：%s\n", outpath);
    return 0;
}

static int register_install(sqlite3 *db, const char *appname, PkgType t, const char *inst_path)
{
    char *err = NULL;
    const char *sql =
    "CREATE TABLE IF NOT EXISTS sys_install ("
    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "appname TEXT UNIQUE NOT NULL,"
    "pkg_type INTEGER NOT NULL,"
    "install_path TEXT NOT NULL,"
    "install_ts INTEGER);";
    sqlite3_exec(db, sql, NULL, NULL, &err);
    if(err) sqlite3_free(err);

    sqlite3_stmt *st;
    const char *ins_sql =
    "INSERT OR REPLACE INTO sys_install(appname, pkg_type, install_path, install_ts)"
    "VALUES (?,?,?,?)";
    if (sqlite3_prepare_v2(db, ins_sql, -1, &st, NULL) != SQLITE_OK)
        return -1;
    sqlite3_bind_text(st, 1, appname, -1, SQLITE_STATIC);
    sqlite3_bind_int(st, 2, (int)t);
    sqlite3_bind_text(st, 3, inst_path, -1, SQLITE_STATIC);
    sqlite3_bind_int(st, 4, (int)time(NULL));
    int rc = sqlite3_step(st);
    sqlite3_finalize(st);
    if (rc == SQLITE_DONE) {
        printf("✅ 系统注册成功：%s\n", appname);
        return 0;
    }
    return -1;
}

static int install_package(sqlite3 *db, const char *pkg_file)
{
    FILE *fp = fopen(pkg_file, "rb");
    if (!fp) {
        fprintf(stderr, "❌ 无法打开包文件 %s\n", pkg_file);
        return -1;
    }
    PkgType pt = detect_pkg_type(fp);
    if (pt == PKG_NONE) {
        fclose(fp);
        fprintf(stderr, "❌ 不是有效的 MIK / AIRADY-EXE 包！\n");
        return -1;
    }
    printf("📦 检测到包类型：%s\n", pkgtype_str(pt));

    // 提取应用名（去掉路径、后缀）
    char appname[256];
    const char *base = strrchr(pkg_file, '/');
    base = base ? base + 1 : pkg_file;
    strncpy(appname, base, sizeof(appname)-1);
    char *dot = strrchr(appname, '.');
    if(dot) *dot = 0;

    char inst_dir[MAX_PATH];
    snprintf(inst_dir, MAX_PATH, "%s/%s", SYS_INST_ROOT, appname);
    printf("📂 目标安装目录：%s\n", inst_dir);

    if (extract_pkg(fp, inst_dir) != 0) {
        fclose(fp);
        return -1;
    }
    fclose(fp);

    return register_install(db, appname, pt, inst_dir);
}

static int list_installed(sqlite3 *db)
{
    sqlite3_stmt *st;
    const char *sql = "SELECT appname, pkg_type, install_path, install_ts FROM sys_install";
    printf("\n===== 系统已安装应用 =====\n");
    if(sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK)
    {
        printf("暂无安装记录\n");
        return 0;
    }
    while(sqlite3_step(st) == SQLITE_ROW)
    {
        const char *name = (const char*)sqlite3_column_text(st,0);
        int t = sqlite3_column_int(st,1);
        const char *p = (const char*)sqlite3_column_text(st,2);
        int ts = sqlite3_column_int(st,3);
        printf("[%s] %s → %s | ts:%d\n", pkgtype_str((PkgType)t), name, p, ts);
    }
    sqlite3_finalize(st);
    printf("==========================\n");
    return 0;
}

static int remove_app(sqlite3 *db, const char *appname)
{
    sqlite3_stmt *st;
    const char *sql_get = "SELECT install_path FROM sys_install WHERE appname=?";
    if(sqlite3_prepare_v2(db, sql_get, -1, &st, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_text(st,1,appname,-1,SQLITE_STATIC);
    if(sqlite3_step(st) != SQLITE_ROW)
    {
        sqlite3_finalize(st);
        printf("❌ 找不到应用 %s\n", appname);
        return -1;
    }
    const char *path = (const char*)sqlite3_column_text(st,0);
    sqlite3_finalize(st);

    // 简单删除文件（真实系统这里递归删目录）
    char binpath[MAX_PATH];
    snprintf(binpath, MAX_PATH, "%s/app.bin", path);
    unlink(binpath);

    const char *sql_del = "DELETE FROM sys_install WHERE appname=?";
    if(sqlite3_prepare_v2(db, sql_del, -1, &st, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_text(st,1,appname,-1,SQLITE_STATIC);
    sqlite3_step(st);
    sqlite3_finalize(st);
    printf("🗑️ 已卸载：%s\n", appname);
    return 0;
}

static void help(void)
{
    printf("==== Airady Package Installer ====\n");
    printf("用法：\n");
    printf("  ./airady_pkg install 包文件.mik/.exe\n");
    printf("  ./airady_pkg list\n");
    printf("  ./airady_pkg remove 应用名\n");
}

int main(int argc, char **argv)
{
    sqlite3 *db;
    if(sqlite3_open(DB_PATH, &db) != SQLITE_OK)
    {
        fprintf(stderr,"打开数据库失败\n");
        return 1;
    }
    if(argc < 2)
    {
        help();
        sqlite3_close(db);
        return 1;
    }
    int ret = 0;
    if(strcmp(argv[1], "install") == 0)
    {
        if(argc <3) { help(); ret=1; }
        else ret = install_package(db, argv[2]);
    }
    else if(strcmp(argv[1], "list") ==0)
    {
        ret = list_installed(db);
    }
    else if(strcmp(argv[1], "remove") ==0)
    {
        if(argc <3) { help(); ret=1; }
        else ret = remove_app(db, argv[2]);
    }
    else
    {
        help();
        ret = 1;
    }
    sqlite3_close(db);
    return ret;
}