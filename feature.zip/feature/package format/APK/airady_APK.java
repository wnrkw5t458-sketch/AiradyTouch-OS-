import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

fun getApkFileSha256(apkFile: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    FileInputStream(apkFile).use { fis ->
        val buf = ByteArray(4096)
        var len: Int
        while (fis.read(buf).also { len = it } > 0) {
            md.update(buf, 0, len)
        }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}
// 使用：val apkPath = applicationInfo.sourceDir; getApkFileSha256(File(apkPath))