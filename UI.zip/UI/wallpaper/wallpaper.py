#!/usr/bin/env python3
"""
AiradyTouch OS Wallpaper Manager v0.1
Python 壁纸管理器，终端ASCII壁纸
可被BootUI、Kivy桌面调用
"""
import os
import json
from pathlib import Path

# 配置文件保存路径
CFG_PATH = Path("wallpaper.cfg")

# 内置壁纸库
WALLPAPERS = {
    "0": {
        "name": "深空青蓝",
        "art": """
        ╔════════════════════════════════════════╗
        ║  ✦  .  ✧        ✦          .         ║
        ║ .        ✦              ✧    .        ║
        ║    ✧    ██████╗ ██╗██████╗ ███████╗   ║
        ║  .      ██╔══██╗██║██╔══██╗██╔════╝   ║
        ║ ✦       ██████╔╝██║██████╔╝█████╗     ║
        ║         ██╔══██╗██║██╔══██╗██╔══╝     ║
        ║ .       ██████╔╝██║██║  ██║███████╗   ║
        ║ ✧       ╚═════╝ ╚═╝╚═╝  ╚═╝╚══════╝   ║
        ║  .        ✦        ✧        ✦        ║
        ╚════════════════════════════════════════╝
        """
    },
    "1": {
        "name": "极简线条",
        "art": """
        ┌────────────────────────────────────────┐
        │                                        │
        │    AiradyTouch OS                      │
        │    ───────────────                     │
        │    Your Custom OS Stack                │
        │                                        │
        └────────────────────────────────────────┘
        """
    },
    "2": {
        "name": "数据流",
        "art": """
        01001001 01101110 0110666
        10101100 01110101 01110100
        01100101 01100010 01110100
             Airady Point IO Ready
        01001001 01101110 0110666
        10101100 01110101 01110100
        """
    },
    "3": {
        "name": "星空波浪",
        "art": """
        ~ ~ ~ ✦ ~ ~ ✧ ~ ~ ✦ ~ ~ ✧ ~ ~
          ~ ✦ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ✧ ~
        ✧ ~ ~ ~ Airady ~ ~ ~ ~ ✦ ~ ~
          ~ ✧ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ✦ ~
        ~ ~ ~ ✧ ~ ~ ✦ ~ ~ ✧ ~ ~ ✦ ~ ~
        """
    }
}


def load_config():
    """加载当前壁纸配置"""
    if CFG_PATH.exists():
        with open(CFG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"current": "0"}


def save_config(cfg):
    """保存配置"""
    with open(CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def clear():
    os.system("clear")


def show_wallpaper(wall_id: str):
    """展示指定壁纸"""
    wp = WALLPAPERS.get(wall_id)
    if not wp:
        print("壁纸不存在！")
        return
    print("\033[36m" + wp["art"] + "\033[0m")
    print(f"\033[32m【壁纸】{wp['name']}\033[0m")


def list_wallpapers():
    """列出全部壁纸"""
    print("\033[33m===== 壁纸列表 =====\033[0m")
    for k, v in WALLPAPERS.items():
        print(f" {k}. {v['name']}")
    print(" 99. 从外部txt文件加载壁纸")
    print(" 0. 返回菜单")


def load_external_wallpaper():
    """加载外部txt作为壁纸"""
    path = input("输入壁纸txt文件路径：").strip()
    p = Path(path)
    if not p.exists():
        print("\033[31m文件不存在！\033[0m")
        return
    with open(p, "r", encoding="utf-8") as f:
        content = f.read()
    clear()
    print("\033[36m" + content + "\033[0m")
    print("\033[32m【外部导入壁纸】\033[0m")


def main():
    cfg = load_config()
    while True:
        clear()
        print("\033[34m===== Airady 壁纸管理器 v0.1 =====\033[0m")
        print(" 1. 预览当前壁纸")
        print(" 2. 浏览并切换壁纸")
        print(" 3. 加载外部txt壁纸")
        print(" 4. 退出")
        choice = input("\n请输入选项：").strip()

        if choice == "1":
            clear()
            show_wallpaper(cfg["current"])
            input("\n按回车返回...")
        elif choice == "2":
            clear()
            list_wallpapers()
            sel = input("选择壁纸编号：").strip()
            if sel == "0":
                continue
            if sel in WALLPAPERS:
                cfg["current"] = sel
                save_config(cfg)
                clear()
                show_wallpaper(sel)
                print("\033[32m✅ 已设为默认壁纸！\033[0m")
                input("\n按回车返回...")
            else:
                print("\033[31m无效编号\033[0m")
                input()
        elif choice == "3":
            clear()
            load_external_wallpaper()
            input("\n按回车返回...")
        elif choice == "4":
            clear()
            print("\033[32m壁纸管理器退出\033[0m")
            break
        else:
            print("\033[31m无效选项\033[0m")
            input()


# 给其他程序调用的接口函数（BootUI / Kivy 直接调用）
def get_current_wallpaper_art():
    cfg = load_config()
    wid = cfg["current"]
    return WALLPAPERS[wid]["art"] if wid in WALLPAPERS else ""


if __name__ == "__main__":
    main()