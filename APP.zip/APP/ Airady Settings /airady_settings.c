/*
 * AiradyTouch OS — Airady Settings v0.1
 * 完整系统设置中心
 * 功能：主机名、时间、亮度模拟、音量模拟、系统信息、设备信息、关于本机
 * 编译：gcc airady_settings.c -o airady_settings
 * 运行：./airady_settings
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define MAX_BUF 256

// 系统全局配置（模拟系统注册表）
char hostname[MAX_BUF] = "AiradyDevice";
int brightness = 80;
int volume = 70;

void show_banner()
{
    printf("\n====================================\n");
    printf("      AiradyTouch OS Settings       \n");
    printf("====================================\n");
}

void show_menu()
{
    printf("\n【系统设置菜单】\n");
    printf(" 1. 修改设备主机名\n");
    printf(" 2. 调节屏幕亮度(模拟)\n");
    printf(" 3. 调节系统音量(模拟)\n");
    printf(" 4. 查看当前系统时间\n");
    printf(" 5. 查看设备信息\n");
    printf(" 6. 查看系统版本信息\n");
    printf(" 0. 退出设置\n");
    printf("------------------------------------\n");
    printf("请输入选项：");
}

void change_hostname()
{
    char newname[MAX_BUF];
    printf("\n当前主机名：%s\n", hostname);
    printf("输入新主机名：");
    fgets(newname, MAX_BUF, stdin);
    newname[strcspn(newname, "\n")] = 0;

    if(strlen(newname) < 2)
    {
        printf("❌ 主机名过短！\n");
        return;
    }

    strcpy(hostname, newname);
    printf("✅ 主机名修改成功！\n");
}

void set_brightness()
{
    int val;
    printf("\n当前亮度：%d%%\n", brightness);
    printf("输入新亮度(0-100)：");
    scanf("%d", &val);
    getchar();

    if(val >= 0 && val <= 100)
    {
        brightness = val;
        printf("✅ 亮度已更新为 %d%%\n", brightness);
    }
    else
        printf("❌ 数值非法！必须 0~100\n");
}

void set_volume()
{
    int val;
    printf("\n当前音量：%d%%\n", volume);
    printf("输入新音量(0-100)：");
    scanf("%d", &val);
    getchar();

    if(val >= 0 && val <= 100)
    {
        volume = val;
        printf("✅ 音量已更新为 %d%%\n", volume);
    }
    else
        printf("❌ 数值非法！必须 0~100\n");
}

void show_time()
{
    time_t now = time(NULL);
    printf("\n🕒 当前系统时间：%s", ctime(&now));
}

void show_device_info()
{
    printf("\n📱 设备信息\n");
    printf("设备名称：%s\n", hostname);
    printf("屏幕亮度：%d%%\n", brightness);
    printf("系统音量：%d%%\n", volume);
    printf("内核版本：Linux 7.3\n");
    printf("系统外壳：Airady Custom C-Shell\n");
    printf("安装包支持：MIK / AIRADY-EXE / APK\n");
}

void show_system_about()
{
    printf("\n💻 关于 AiradyTouch OS\n");
    printf("系统名称：AiradyTouch OS\n");
    printf("开发语言：纯 C 底层外壳\n");
    printf("架构：自定义移动端触控系统\n");
    printf("应用生态：Airady Store 专属生态\n");
    printf("打包格式：自研 MIK / EXE 双格式\n");
    printf("兼容层：原生支持 Android APK\n");
    printf("状态：完整自研操作系统栈\n");
}

int main()
{
    int op;
    show_banner();

    while(1)
    {
        show_menu();
        scanf("%d", &op);
        getchar();

        switch(op)
        {
            case 1: change_hostname(); break;
            case 2: set_brightness(); break;
            case 3: set_volume(); break;
            case 4: show_time(); break;
            case 5: show_device_info(); break;
            case 6: show_system_about(); break;
            case 0:
                printf("\n👋 退出系统设置\n");
                return 0;
            default:
                printf("❌ 无效选项！\n");
        }
    }

    return 0;
}