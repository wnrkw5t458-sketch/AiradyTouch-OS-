/*
 * AiradyTouch OS - Airady Calculator v0.1
 * 交互式命令行计算器
 * 编译：gcc airady_calc.c -o airady_calc -lm
 * 使用：./airady_calc
 * 支持：+ - * / () 小数
 * 输入 q 退出
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#define MAX_EXPR 256

static double eval(char *s, int *pos);

static double number(char *s, int *pos)
{
    double res = 0.0;
    while (isdigit((unsigned char)s[*pos]))
    {
        res = res * 10 + (s[*pos] - '0');
        (*pos)++;
    }
    if (s[*pos] == '.')
    {
        (*pos)++;
        double frac = 0.1;
        while (isdigit((unsigned char)s[*pos]))
        {
            res += (s[*pos] - '0') * frac;
            frac *= 0.1;
            (*pos)++;
        }
    }
    return res;
}

static double factor(char *s, int *pos)
{
    double val;
    if (s[*pos] == '(')
    {
        (*pos)++;
        val = eval(s, pos);
        if (s[*pos] == ')')
            (*pos)++;
        return val;
    }
    return number(s, pos);
}

static double term(char *s, int *pos)
{
    double res = factor(s, pos);
    while (s[*pos] == '*' || s[*pos] == '/')
    {
        char op = s[*pos];
        (*pos)++;
        double b = factor(s, pos);
        if (op == '*')
            res *= b;
        else
            res /= b;
    }
    return res;
}

static double eval(char *s, int *pos)
{
    double res = term(s, pos);
    while (s[*pos] == '+' || s[*pos] == '-')
    {
        char op = s[*pos];
        (*pos)++;
        double b = term(s, pos);
        if (op == '+')
            res += b;
        else
            res -= b;
    }
    return res;
}

static double calculate(char *expr)
{
    int p = 0;
    return eval(expr, &p);
}

static void trim_space(char *dst, const char *src)
{
    int i = 0, j = 0;
    while (src[j])
    {
        if (!isspace((unsigned char)src[j]))
            dst[i++] = src[j];
        j++;
    }
    dst[i] = 0;
}

int main(void)
{
    char line[MAX_EXPR];
    char expr[MAX_EXPR];
    printf("=============================\n");
    printf("    Airady Calculator v0.1   \n");
    printf("=============================\n");
    printf("输入算式，例如：(2+3)*4.5\n");
    printf("输入 q 退出计算器\n\n");

    for (;;)
    {
        printf("calc> ");
        if (!fgets(line, MAX_EXPR, stdin))
            break;
        trim_space(expr, line);
        if (strcmp(expr, "q") == 0 || strcmp(expr, "quit") == 0)
        {
            printf("👋 退出计算器\n");
            break;
        }
        if (expr[0] == 0)
            continue;
        double ans = calculate(expr);
        printf("= %.6g\n\n", ans);
    }
    return 0;
}