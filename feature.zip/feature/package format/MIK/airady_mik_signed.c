/*
 * Airady MIK with SHA256 Signature v0.2
 * 带签名校验 .mik
 * 依赖：需要系统支持 openssl（gcc 链接 -lcrypto）
 * 编译命令：gcc airady_mik_signed.c -o airady_mik -lcrypto
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <openssl/sha.h>

#define MIK_MAGIC "AIRADYMIK"
#define MAGIC_LEN 8
#define PKG_NAME_MAX 64
#define VER_MAX 32
#define DESC_MAX 256
#define CMD_MAX 256
#define DEP_MAX 256
#define INSTALL_ROOT "./mik_packages/"
#define META_SUFFIX ".meta"
#define SIG_LEN SHA256_DIGEST_LENGTH

typedef struct {
    char magic[MAGIC_LEN];
    unsigned short fmt_ver;
    char pkg_name[PKG_NAME_MAX];
    char version[VER_MAX];
    char desc[DESC_MAX];
    char run_cmd[CMD_MAX];
    char depends[DEP_MAX];
    long bin_size;
    char reserved[64];
} MikHeader;

static int mkpath(const char *path) {
    char tmp[512];
    char *p;
    strncpy(tmp, path, sizeof(tmp)-1);
    for(p = tmp + 1; *p; p++) {
        if(*p == '/') {
            *p = 0;
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    mkdir(tmp, 0755);
    return 0;
}

static long get_file_size(FILE *fp) {
    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    return sz;
}

/* 计算文件除去末尾SIG_LEN字节的sha256 */
static int calc_sha256(FILE *fp, unsigned char out_hash[SIG_LEN]) {
    fseek(fp, 0, SEEK_SET);
    long total = get_file_size(fp);
    long data_len = total - SIG_LEN;
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    char buf[4096];
    long left = data_len;
    long r;
    while(left > 0 && (r = fread(buf,1,sizeof(buf),fp))>0) {
        if(r > left) r = left;
        SHA256_Update(&ctx, buf, r);
        left -= r;
    }
    SHA256_Final(out_hash, &ctx);
    return 0;
}

/* 校验签名：返回0=合法，-1=篡改/无效 */
static int mik_verify(const char *mikfile) {
    FILE *fp = fopen(mikfile, "rb");
    if(!fp) return -1;
    long fsz = get_file_size(fp);
    if(fsz <= SIG_LEN) { fclose(fp); return -1; }
    unsigned char calc_hash[SIG_LEN];
    calc_sha256(fp, calc_hash);

    // 读取保存的签名
    unsigned char stored_hash[SIG_LEN];
    fseek(fp, fsz - SIG_LEN, SEEK_SET);
    fread(stored_hash, 1, SIG_LEN, fp);
    fclose(fp);

    if(memcmp(calc_hash, stored_hash, SIG_LEN) == 0) return 0;
    return -1;
}

/* 打包：原有逻辑，最后追加sha256签名 */
static int mik_pack(const char *bin_path, const char *out_mik) {
    FILE *fin = fopen(bin_path, "rb");
    if(!fin) { perror("open bin"); return -1; }
    FILE *fout = fopen(out_mik, "wb");
    if(!fout) { perror("create mik"); fclose(fin); return -1; }

    MikHeader hdr;
    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, MIK_MAGIC, MAGIC_LEN);
    hdr.fmt_ver = 1;

    printf("=== 打包 MIK（带签名）===\n");
    printf("输入包名：");
    scanf("%s", hdr.pkg_name);
    printf("输入软件版本：");
    scanf("%s", hdr.version);
    getchar();
    printf("输入软件描述：");
    fgets(hdr.desc, DESC_MAX, stdin);
    hdr.desc[strcspn(hdr.desc, "\n")] = 0;
    printf("输入启动命令：");
    fgets(hdr.run_cmd, CMD_MAX, stdin);
    hdr.run_cmd[strcspn(hdr.run_cmd, "\n")] = 0;
    printf("输入依赖，无依赖回车：");
    fgets(hdr.depends, DEP_MAX, stdin);
    hdr.depends[strcspn(hdr.depends, "\n")] = 0;

    long bsize = get_file_size(fin);
    hdr.bin_size = bsize;
    fwrite(&hdr, sizeof(MikHeader), 1, fout);

    char buf[4096];
    long rd;
    while((rd = fread(buf,1,sizeof(buf),fin))>0) {
        fwrite(buf,1,rd,fout);
    }
    fclose(fin);
    fclose(fout);

    // 重新打开，计算哈希并追加签名
    FILE *fp = fopen(out_mik, "r+b");
    unsigned char hash[SIG_LEN];
    calc_sha256(fp, hash);
    fseek(fp, 0, SEEK_END);
    fwrite(hash,1,SIG_LEN,fp);
    fclose(fp);
    printf("\n✅ 打包+签名成功：%s\n", out_mik);
    return 0;
}

static int mik_read_header(const char *mikfile, MikHeader *hdr) {
    if(mik_verify(mikfile) != 0) {
        printf("❌ MIK签名校验失败！文件被篡改\n");
        return -4;
    }
    FILE *fp = fopen(mikfile, "rb");
    if(!fp) { perror("open mik"); return -1; }
    if(fread(hdr, sizeof(MikHeader),1,fp) !=1) { fclose(fp); return -2; }
    if(memcmp(hdr->magic, MIK_MAGIC, MAGIC_LEN)!=0) {
        printf("❌ 不是合法MIK包\n");
        fclose(fp); return -3;
    }
    fclose(fp);
    return 0;
}

static int mik_info(const char *mikfile) {
    MikHeader hdr;
    int ret = mik_read_header(mikfile, &hdr);
    if(ret !=0) return ret;
    printf("\n===== MIK 包信息（签名校验通过）=====\n");
    printf("包名：%s\n版本：%s\n描述：%s\n启动命令：%s\n依赖：%s\n二进制大小：%ld\n",
           hdr.pkg_name, hdr.version, hdr.desc, hdr.run_cmd,
           hdr.depends[0]?hdr.depends:"无", hdr.bin_size);
    return 0;
}

static int mik_install(const char *mikfile) {
    MikHeader hdr;
    int ret = mik_read_header(mikfile, &hdr);
    if(ret !=0) return ret;

    char pkg_dir[512];
    snprintf(pkg_dir, sizeof(pkg_dir), "%s%s/", INSTALL_ROOT, hdr.pkg_name);
    mkpath(pkg_dir);

    FILE *fin = fopen(mikfile, "rb");
    fseek(fin, sizeof(MikHeader), SEEK_SET);
    char bin_path[512];
    snprintf(bin_path, sizeof(bin_path), "%s%s", pkg_dir, hdr.pkg_name);
    FILE *fbin = fopen(bin_path, "wb");

    char buf[4096];
    long left = hdr.bin_size;
    long r;
    while(left>0 && (r=fread(buf,1,sizeof(buf),fin))>0) {
        fwrite(buf,1,r,fbin);
        left -= r;
    }
    fclose(fin);
    fclose(fbin);
    chmod(bin_path,0755);

    char meta_path[512];
    snprintf(meta_path, sizeof(meta_path), "%s%s%s", pkg_dir, hdr.pkg_name, META_SUFFIX);
    FILE *fmeta = fopen(meta_path, "w");
    fprintf(fmeta,"name=%s\nver=%s\ndesc=%s\nrun=%s\ndep=%s\n",
            hdr.pkg_name, hdr.version, hdr.desc, hdr.run_cmd, hdr.depends);
    fclose(fmeta);
    printf("✅ MIK安装完成：%s\n", hdr.pkg_name);
    return 0;
}

static int mik_run(const char *pkgname) {
    char bin_path[512];
    snprintf(bin_path, sizeof(bin_path), "%s%s/%s", INSTALL_ROOT, pkgname, pkgname);
    struct stat st;
    if(stat(bin_path, &st)!=0) {
        printf("❌ 软件 %s 未安装\n", pkgname);
        return -1;
    }
    printf("🚀 启动 %s\n", pkgname);
    pid_t pid = fork();
    if(pid == 0) {
        execl(bin_path, bin_path, (char*)NULL);
        exit(127);
    }
    return 0;
}

static int mik_list(void) {
    DIR *d = opendir(INSTALL_ROOT);
    if(!d) { printf("📦 无已安装MIK软件\n"); return 0; }
    printf("\n===== MIK列表 =====\n");
    struct dirent *ent;
    while((ent = readdir(d))) {
        if(ent->d_type == DT_DIR && ent->d_name[0] != '.')
            printf(" • %s\n", ent->d_name);
    }
    closedir(d);
    return 0;
}

static int mik_uninstall(const char *pkgname) {
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "rm -rf %s%s/", INSTALL_ROOT, pkgname);
    printf("🗑️ 卸载 %s\n", pkgname);
    system(cmd);
    printf("✅ 卸载完成\n");
    return 0;
}

static void help(void) {
    printf("Airady MIK (Signed SHA256) v0.2\n");
    printf("命令：pack / info / install / run / list / uninstall / verify\n");
    printf("  verify xxx.mik 单独校验签名\n");
}

int main(int argc, char **argv) {
    if(argc <2) { help(); return1; }
    if(strcmp(argv[1],"pack")==0) {
        if(argc<4) { printf("pack bin out.mik\n"); return1; }
        mik_pack(argv[2],argv[3]);
    } else if(strcmp(argv[1],"verify")==0) {
        if(argc<3) return1;
        if(mik_verify(argv[2])==0) printf("✅ 签名校验通过\n");
        else printf("❌ 签名校验失败\n");
    } else if(strcmp(argv[1],"info")==0) {
        if(argc<3) return1; mik_info(argv[2]);
    } else if(strcmp(argv[1],"install")==0) {
        if(argc<3) return1; mik_install(argv[2]);
    } else if(strcmp(argv[1],"run")==0) {
        if(argc<3) return1; mik_run(argv[2]);
    } else if(strcmp(argv[1],"list")==0) { mik_list(); }
    else if(strcmp(argv[1],"uninstall")==0) {
        if(argc<3) return1; mik_uninstall(argv[2]);
    } else { help(); return1; }
    return 0;
}