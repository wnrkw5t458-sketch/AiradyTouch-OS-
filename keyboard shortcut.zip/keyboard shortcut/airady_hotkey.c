/*
 * Airady Hotkey Daemon v0.1
 * C 跨端快捷键服务：PC + 移动端(iSH/Termux)
 * 热键表：
 * F1    airady_shell
 * F2    airady_files
 * F3    airady_editor
 * F4    airady_calc
 * F5    airady_audio
 * F6    airady_io
 * F7    airady_settings
 * ESC   返回桌面（发送启动bootui）
 * Ctrl+Q 退出热键服务
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <signal.h>
#include <string.h>

// 热键对应的启动命令
typedef struct {
    const char *key_name;
    const char *cmd;
} Hotkey;

Hotkey hotlist[] = {
    {"F1", "./airady_shell"},
    {"F2", "./airady_files"},
    {"F3", "./airady_editor"},
    {"F4", "./airady_calc"},
    {"F5", "./airady_audio"},
    {"F6", "./airady_io"},
    {"F7", "./airady_settings"},
    {"ESC", "python3 airady_bootui.py"},
    {"Ctrl+Q", "__QUIT__"},
    {NULL, NULL}
};

static struct termios old_term;
static int running = 1;

// 恢复终端
void restore_terminal(void) {
    tcsetattr(STDIN_FILENO, TCSANOW, &old_term);
}

// SIGINT 信号处理
void sig_handler(int sig) {
    (void)sig;
    running = 0;
    printf("\n[Hotkey] 收到停止信号，退出守护\n");
}

// 执行命令
void run_command(const char *cmd) {
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return;
    }
    if (pid == 0) {
        execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
        exit(127);
    }
}

// 打印触屏快捷菜单（移动端无键盘时使用）
void show_touch_menu(void) {
    printf("\n===== Airady 快捷面板（触屏模式）=====\n");
    for (int i = 0; hotlist[i].key_name; i++) {
        printf(" %d. %-8s -> %s\n", i+1, hotlist[i].key_name, hotlist[i].cmd);
    }
    printf(" 0. 退出热键服务\n");
    printf("======================================\n");
    printf("请输入序号：");
}

// 键盘原始模式捕获按键
void keyboard_loop(void) {
    struct termios new_term;
    tcgetattr(STDIN_FILENO, &old_term);
    atexit(restore_terminal);
    new_term = old_term;
    // 关闭回显、行缓冲
    new_term.c_lflag &= ~(ECHO | ICANON);
    new_term.c_cc[VMIN] = 1;
    new_term.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &new_term);

    unsigned char c;
    while (running) {
        read(STDIN_FILENO, &c, 1);

        // ESC 序列（F1-F5 等功能键都是 ESC 开头）
        if (c == 0x1B) {
            unsigned char seq[2];
            read(STDIN_FILENO, seq, 2);
            if (seq[0] == '[') {
                switch (seq[1]) {
                    case 'A': printf("[Hotkey] F1\n"); run_command("./airady_shell"); break;
                    case 'B': printf("[Hotkey] F2\n"); run_command("./airady_files"); break;
                    case 'C': printf("[Hotkey] F3\n"); run_command("./airady_editor"); break;
                    case 'D': printf("[Hotkey] F4\n"); run_command("./airady_calc"); break;
                    case 'E': printf("[Hotkey] F5\n"); run_command("./airady_audio"); break;
                }
            }
            // ESC 单独按下
            if (seq[0] == 0) {
                printf("[Hotkey] ESC 返回桌面\n");
                run_command("python3 airady_bootui.py");
            }
        }
        // Ctrl+Q = 0x11
        else if (c == 0x11) {
            printf("[Hotkey] Ctrl+Q 退出热键服务\n");
            running = 0;
        }
        // F6/F7 在不同终端的编码不一样，这里预留，你可以按终端微调
        else if (c == 0x06) {
            printf("[Hotkey] F6 Point IO\n");
            run_command("./airady_io");
        } else if (c == 0x07) {
            printf("[Hotkey] F7 Settings\n");
            run_command("./airady_settings");
        }
    }
}

int main(int argc, char **argv) {
    signal(SIGINT, sig_handler);
    int touch_mode = 0;

    // 参数 -t 开启触屏菜单模式（移动端纯触屏）
    if (argc >=2 && strcmp(argv[1], "-t") == 0) {
        touch_mode = 1;
    }

    printf("Airady Hotkey Service v0.1 (C)\n");
    if (touch_mode) {
        printf("运行模式：触屏快捷面板（移动端无键盘）\n");
        while (running) {
            show_touch_menu();
            int opt;
            if (scanf("%d", &opt) != 1) break;
            if (opt == 0) {
                running = 0;
                break;
            }
            if (opt >=1 && opt <=7) {
                run_command(hotlist[opt-1].cmd);
            } else if (opt ==8) {
                run_command("python3 airady_bootui.py");
            } else {
                printf("无效选项\n");
            }
        }
    } else {
        printf("运行模式：键盘捕获模式（PC / 蓝牙键盘）\n");
        printf("F1~F7 启动程序 | ESC 返回桌面 | Ctrl+Q 退出\n");
        keyboard_loop();
    }
    printf("Hotkey daemon stopped.\n");
    return 0;
}



