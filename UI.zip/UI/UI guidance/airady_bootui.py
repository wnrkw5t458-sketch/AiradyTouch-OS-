#!/usr/bin/env python3
"""
AiradyTouch OS Boot UI v0.1
Python 终端图形引导界面
可以调用所有C写的系统程序
"""
import os
import sys
import subprocess
import time

# ANSI颜色
class Color:
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    BOLD = "\033[1m"


def clear_screen():
    os.system("clear")


def print_banner():
    banner = r"""
    ╔══════════════════════════════════════════════════╗
    ║                                                  ║
    ║   █████╗ ██╗██████╗ ██████╗ █████╗ ██████╗ ██╗   ║
    ║  ██╔══██╗██║██╔══██╗██╔══██╗██╔══██╗██╔══██╗██║   ║
    ║  ███████║██║██████╔╝██████╔╝███████║██████╔╝██║   ║
    ║  ██╔══██║██║██╔══██╗██╔══██╗██╔══██║██╔══██╗██║   ║
    ║  ██║  ██║██║██║  ██║██████╔╝██║  ██║██║  ██║██║   ║
    ║  ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ║
    ║                                                  ║
    ║          AiradyTouch OS  Boot UI                 ║
    ╚══════════════════════════════════════════════════╝
    """
    print(Color.CYAN + Color.BOLD + banner + Color.RESET)


def show_system_info():
    print(Color.GREEN + "[系统信息]" + Color.RESET)
    print(f"  系统名称: AiradyTouch OS")
    print(f"  UI版本:  BootUI Python v0.1")
    print(f"  运行环境: {sys.platform}")
    print(f"  Python版本: {sys.version.split()[0]}")
    print(f"  应用格式: MIK / AIRADY-EXE")
    print(f"  底层工具: 11个C原生组件\n")


def show_menu():
    menu_list = [
        ("1", "Airady Shell    系统终端"),
        ("2", "Airady Files    文件管理器"),
        ("3", "Airady Editor   文本编辑器"),
        ("4", "Airady Calc     计算器"),
        ("5", "Airady Audio    WAV音频播放器"),
        ("6", "Ziply           解压工具"),
        ("7", "Airady Dev      MIK打包器"),
        ("8", "Airady Pkg      包安装器"),
        ("9", "Airady Store    应用商店"),
        ("10", "Airady Settings 系统设置"),
        ("11", "Airady IO       Point IO调试控制台"),
        ("0", "退出引导界面，返回命令行"),
    ]
    print(Color.YELLOW + Color.BOLD + "【主菜单 - 选择要启动的程序】" + Color.RESET)
    for key, text in menu_list:
        print(f"  {key:>2s}. {text}")
    print("\n请输入选择编号 > ", end="")


def run_program(choice: str):
    prog_map = {
        "1": "./airady_shell",
        "2": "./airady_files",
        "3": "./airady_editor",
        "4": "./airady_calc",
        "5": "./airady_audio",
        "6": "./ziply",
        "7": "./airady_dev",
        "8": "./airady_pkg",
        "9": "./airady_store",
        "10": "./airady_settings",
        "11": "./airady_io",
    }
    if choice not in prog_map:
        print(Color.RED + "无效选项！" + Color.RESET)
        time.sleep(1.2)
        return

    cmd = prog_map[choice]
    print(Color.MAGENTA + f"\n正在启动: {cmd}" + Color.RESET)
    time.sleep(0.6)
    try:
        subprocess.run(cmd, shell=True)
    except FileNotFoundError:
        print(Color.RED + f"错误：找不到程序 {cmd}，确认已经编译！" + Color.RESET)
    except Exception as e:
        print(Color.RED + f"启动失败: {e}" + Color.RESET)
    print("\n按回车回到引导界面...")
    input()


def boot_animation():
    print(Color.CYAN + "系统正在加载...", end="")
    for i in range(6):
        time.sleep(0.25)
        print(".", end="", flush=True)
    print(Color.RESET + "\n")
    time.sleep(0.4)


def main():
    while True:
        clear_screen()
        print_banner()
        boot_animation()
        show_system_info()
        show_menu()
        sel = input().strip()
        if sel == "0":
            clear_screen()
            print(Color.GREEN + "👋 退出BootUI，欢迎来到AiradyTouch OS命令行" + Color.RESET)
            break
        run_program(sel)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        clear_screen()
        print(Color.RED + "\n\n引导界面被中断，系统退出" + Color.RESET)