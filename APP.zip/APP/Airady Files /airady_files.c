/*
 * AiradyTouch OS - Airady Files v0.1
 * 命令行文件管理器
 * 编译：gcc airady_files.c -o airady_files
 * 运行：./airady_files
 * 命令：ls cd pwd cp mv rm mkdir touch info exit help
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

#define MAX_PATH 512
#define MAX_ARG 64
#define MAX_LINE 256

static char cwd[MAX_PATH];

static void refresh_cwd(void)
{
    getcwd(cwd, MAX_PATH);
}

static void show_prompt(void)
{
    printf("\n[AiradyFiles] %s > ", cwd);
}

static int file_exists(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0;
}

static int is_dir(const char *path)
{
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    return S_ISDIR(st.st_mode);
}

static void do_ls(void)
{
    DIR *d = opendir(cwd);
    if (!d)
    {
        perror("ls");
        return;
    }
    struct dirent *ent;
    printf("\n📂 当前目录内容：\n");
    while ((ent = readdir(d)) != NULL)
    {
        if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0)
            continue;
        char full[MAX_PATH];
        snprintf(full, MAX_PATH, "%s/%s", cwd, ent->d_name);
        if (is_dir(full))
            printf("  [DIR] %s\n", ent->d_name);
        else
            printf("  [FILE] %s\n", ent->d_name);
    }
    closedir(d);
}

static void do_cd(const char *target)
{
    char newpath[MAX_PATH];
    if (target[0] == '/')
        strncpy(newpath, target, MAX_PATH);
    else
        snprintf(newpath, MAX_PATH, "%s/%s", cwd, target);

    if (chdir(newpath) != 0)
    {
        perror("cd");
        return;
    }
    refresh_cwd();
}

static void do_pwd(void)
{
    printf("\n%s\n", cwd);
}

static void do_mkdir(const char *name)
{
    char full[MAX_PATH];
    snprintf(full, MAX_PATH, "%s/%s", cwd, name);
    if (mkdir(full, 0755) != 0)
    {
        perror("mkdir");
    }
    else
    {
        printf("✅ 文件夹创建成功：%s\n", name);
    }
}

static void do_touch(const char *name)
{
    char full[MAX_PATH];
    snprintf(full, MAX_PATH, "%s/%s", cwd, name);
    FILE *f = fopen(full, "a");
    if (!f)
    {
        perror("touch");
        return;
    }
    fclose(f);
    printf("✅ 文件创建成功：%s\n", name);
}

static void do_rm(const char *name)
{
    char full[MAX_PATH];
    snprintf(full, MAX_PATH, "%s/%s", cwd, name);
    if (unlink(full) != 0)
    {
        perror("rm");
    }
    else
    {
        printf("🗑️ 已删除：%s\n", name);
    }
}

static void do_mv(const char *srcname, const char *dstname)
{
    char src[MAX_PATH], dst[MAX_PATH];
    snprintf(src, MAX_PATH, "%s/%s", cwd, srcname);
    snprintf(dst, MAX_PATH, "%s/%s", cwd, dstname);
    if (rename(src, dst) != 0)
    {
        perror("mv");
    }
    else
    {
        printf("✅ 移动/重命名完成\n");
    }
}

static void do_cp(const char *srcname, const char *dstname)
{
    char src[MAX_PATH], dst[MAX_PATH];
    snprintf(src, MAX_PATH, "%s/%s", cwd, srcname);
    snprintf(dst, MAX_PATH, "%s/%s", cwd, dstname);

    FILE *fin = fopen(src, "rb");
    if (!fin)
    {
        perror("cp source");
        return;
    }
    FILE *fout = fopen(dst, "wb");
    if (!fout)
    {
        perror("cp dest");
        fclose(fin);
        return;
    }
    char buf[4096];
    size_t r;
    while ((r = fread(buf, 1, 4096, fin)) > 0)
    {
        fwrite(buf, 1, r, fout);
    }
    fclose(fin);
    fclose(fout);
    printf("✅ 复制完成\n");
}

static void do_info(const char *name)
{
    char full[MAX_PATH];
    snprintf(full, MAX_PATH, "%s/%s", cwd, name);
    struct stat st;
    if (stat(full, &st) != 0)
    {
        perror("info");
        return;
    }
    printf("\n📄 文件信息：%s\n", name);
    printf("大小：%lld 字节\n", (long long)st.st_size);
    printf("权限：%o\n", st.st_mode & 0777);
    printf("修改时间：%s", ctime(&st.st_mtime));
}

static void help(void)
{
    printf("\n==== Airady Files 帮助 ====\n");
    printf("ls                 列出目录\n");
    printf("cd 文件夹名        进入目录\n");
    printf("pwd                查看当前路径\n");
    printf("mkdir 名字         新建文件夹\n");
    printf("touch 名字         新建空文件\n");
    printf("rm 文件            删除文件\n");
    printf("mv 源 目标         移动/重命名\n");
    printf("cp 源 目标         复制文件\n");
    printf("info 文件          查看文件详情\n");
    printf("help               本帮助\n");
    printf("exit               退出文件管理器\n");
    printf("===========================\n");
}

static void split_cmd(char *line, char **argv, int *argc)
{
    *argc = 0;
    char *tok = strtok(line, " \t\n");
    while (tok && *argc < MAX_ARG - 1)
    {
        argv[(*argc)++] = tok;
        tok = strtok(NULL, " \t\n");
    }
    argv[*argc] = NULL;
}

int main(void)
{
    refresh_cwd();
    char line[MAX_LINE];
    char *argv[MAX_ARG];
    int argc;

    printf("=====================================\n");
    printf("      Airady Files v0.1              \n");
    printf("  输入 help 查看全部命令              \n");
    printf("=====================================\n");

    for (;;)
    {
        show_prompt();
        if (!fgets(line, MAX_LINE, stdin))
        {
            break;
        }
        split_cmd(line, argv, &argc);
        if (argc == 0) continue;

        if (strcmp(argv[0], "exit") == 0)
        {
            printf("👋 退出 Airady Files\n");
            break;
        }
        if (strcmp(argv[0], "help") == 0)
        {
            help();
            continue;
        }
        if (strcmp(argv[0], "ls") == 0)
        {
            do_ls();
            continue;
        }
        if (strcmp(argv[0], "pwd") == 0)
        {
            do_pwd();
            continue;
        }
        if (strcmp(argv[0], "cd") == 0)
        {
            if (argc >= 2) do_cd(argv[1]);
            else printf("cd 需要参数\n");
            continue;
        }
        if (strcmp(argv[0], "mkdir") == 0)
        {
            if (argc >= 2) do_mkdir(argv[1]);
            else printf("mkdir 需要名字\n");
            continue;
        }
        if (strcmp(argv[0], "touch") == 0)
        {
            if (argc >= 2) do_touch(argv[1]);
            else printf("touch 需要名字\n");
            continue;
        }
        if (strcmp(argv[0], "rm") == 0)
        {
            if (argc >= 2) do_rm(argv[1]);
            else printf("rm 需要文件名\n");
            continue;
        }
        if (strcmp(argv[0], "mv") == 0)
        {
            if (argc >= 3) do_mv(argv[1], argv[2]);
            else printf("mv 需要源和目标\n");
            continue;
        }
        if (strcmp(argv[0], "cp") == 0)
        {
            if (argc >= 3) do_cp(argv[1], argv[2]);
            else printf("cp 需要源和目标\n");
            continue;
        }
        if (strcmp(argv[0], "info") == 0)
        {
            if (argc >= 2) do_info(argv[1]);
            else printf("info 需要文件名\n");
            continue;
        }
        printf("❌ 未知命令，输入 help 查看列表\n");
    }
    return 0;
}