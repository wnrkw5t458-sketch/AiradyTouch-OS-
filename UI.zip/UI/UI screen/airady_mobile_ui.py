#!/usr/bin/env python3
"""
AiradyTouch OS Mobile Desktop UI v0.1
移动端触控桌面 | Kivy
适配安卓/iPhone平板，触摸卡片，多页面导航
可在 Termux、Pydroid3、iSH 运行；Buildozer打包APK
"""
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window
from kivy.clock import Clock
import subprocess
import os

# -------------------------- 配置：你的C程序列表 --------------------------
APP_LIST = [
    ("Shell", "./airady_shell"),
    ("Files", "./airady_files"),
    ("Editor", "./airady_editor"),
    ("Calc", "./airady_calc"),
    ("Audio", "./airady_audio"),
    ("Ziply", "./ziply"),
    ("Dev", "./airady_dev"),
    ("Pkg", "./airady_pkg"),
    ("Store", "./airady_store"),
    ("Settings", "./airady_settings"),
    ("PointIO", "./airady_io"),
]

# 主题色 Airady 青蓝色
COLOR_BG = (0.05,0.08,0.12,1)
COLOR_CARD = (0.12,0.22,0.32,1)
COLOR_ACCENT = (0.15,0.75,0.85,1)
COLOR_TEXT = (0.95,0.95,0.95,1)

# -------------------------- 开机闪屏页 --------------------------
class BootScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation="vertical", padding=40, spacing=20)
        with layout.canvas.before:
            Color(*COLOR_BG)
            self.rect = Rectangle(size=layout.size, pos=layout.pos)
        layout.bind(size=self._update_rect, pos=self._update_rect)

        title = Label(text="AiradyTouch OS", font_size=42, color=COLOR_ACCENT, bold=True)
        sub = Label(text="Mobile Booting...", font_size=22, color=COLOR_TEXT)
        layout.add_widget(title)
        layout.add_widget(sub)
        self.add_widget(layout)
        Clock.schedule_once(self.goto_desktop, 2.2)

    def _update_rect(self, inst, value):
        self.rect.pos = inst.pos
        self.rect.size = inst.size

    def goto_desktop(self, dt):
        self.manager.current = "desktop"

# -------------------------- 主桌面：应用卡片页 --------------------------
class DesktopScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = BoxLayout(orientation="vertical")
        # 顶部标题栏
        header = BoxLayout(size_hint_y=0.12, padding=[10,4])
        with header.canvas.before:
            Color(0.08,0.14,0.20,1)
            self.h_rect = Rectangle(size=header.size, pos=header.pos)
        header.bind(size=self._update_h, pos=self._update_h)
        header.add_widget(Label(text="Airady 桌面", font_size=26, color=COLOR_ACCENT, bold=True))
        root.add_widget(header)

        # 应用卡片网格：手机3列，平板4列
        grid = GridLayout(cols=3, spacing=12, padding=12)
        for name, cmd in APP_LIST:
            btn = Button(text=name, font_size=18, background_color=COLOR_CARD, color=COLOR_TEXT)
            btn.bind(on_press=lambda b,c=cmd: self.launch_app(c))
            grid.add_widget(btn)
        root.add_widget(grid)

        # 底部导航栏
        nav = BoxLayout(size_hint_y=0.1, spacing=4, padding=[8,2])
        with nav.canvas.before:
            Color(0.07,0.12,0.18,1)
            self.n_rect = Rectangle(size=nav.size, pos=nav.pos)
        nav.bind(size=self._update_n, pos=self._update_n)
        btn_home = Button(text="桌面", background_color=COLOR_ACCENT)
        btn_info = Button(text="系统信息", background_color=COLOR_CARD)
        btn_sys = Button(text="设置", background_color=COLOR_CARD)
        btn_home.bind(on_press=lambda x: self.manager.set_current("desktop"))
        btn_info.bind(on_press=lambda x: self.manager.set_current("info"))
        btn_sys.bind(on_press=lambda x: self.manager.set_current("system"))
        nav.add_widget(btn_home)
        nav.add_widget(btn_info)
        nav.add_widget(btn_sys)
        root.add_widget(nav)

        with root.canvas.before:
            Color(*COLOR_BG)
            self.bg_rect = Rectangle(size=root.size, pos=root.pos)
        root.bind(size=self._update_bg, pos=self._update_bg)
        self.add_widget(root)

    def _update_bg(self, i,v): self.bg_rect.pos=i.pos; self.bg_rect.size=i.size
    def _update_h(self, i,v): self.h_rect.pos=i.pos; self.h_rect.size=i.size
    def _update_n(self, i,v): self.n_rect.pos=i.pos; self.n_rect.size=i.size

    def launch_app(self, command):
        """启动C程序，在终端打开"""
        try:
            subprocess.Popen(command, shell=True)
        except Exception as e:
            print(f"启动失败: {e}")

# -------------------------- 系统信息页 --------------------------
class InfoScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation="vertical", padding=24, spacing=16)
        with layout.canvas.before:
            Color(*COLOR_BG)
            self.rect = Rectangle(size=layout.size, pos=layout.pos)
        layout.bind(size=self._update_rect, pos=self._update_rect)
        layout.add_widget(Label(text="系统信息", font_size=30, color=COLOR_ACCENT, bold=True))
        info_text = """
系统名称：AiradyTouch OS
UI版本：Mobile Kivy v0.1
架构：自研C底层 + Python触控UI
应用格式：MIK / AIRADY-EXE
组件总数：11个原生C工具
支持：Termux / iSH / Pydroid3
打包：Buildozer → Android APK
        """
        layout.add_widget(Label(text=info_text, font_size=18, color=COLOR_TEXT))
        back = Button(text="返回桌面", size_hint_y=0.12, background_color=COLOR_ACCENT)
        back.bind(on_press=lambda x: self.manager.current="desktop")
        layout.add_widget(back)
        self.add_widget(layout)
    def _update_rect(self, i,v): self.rect.pos=i.pos; self.rect.size=i.size

# -------------------------- 设置页面 --------------------------
class SystemScreen(Screen):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation="vertical", padding=24, spacing=14)
        with layout.canvas.before:
            Color(*COLOR_BG)
            self.rect = Rectangle(size=layout.size, pos=layout.pos)
        layout.bind(size=self._update_rect, pos=self._update_rect)
        layout.add_widget(Label(text="系统设置", font_size=30, color=COLOR_ACCENT, bold=True))
        layout.add_widget(Label(text="亮度、音量、主机名（对接airady_settings）", font_size=18, color=COLOR_TEXT))
        btn_open_settings = Button(text="打开设置程序", background_color=COLOR_CARD)
        btn_open_settings.bind(on_press=lambda x: subprocess.Popen("./airady_settings", shell=True))
        layout.add_widget(btn_open_settings)
        back = Button(text="返回桌面", size_hint_y=0.12, background_color=COLOR_ACCENT)
        back.bind(on_press=lambda x: self.manager.current="desktop")
        layout.add_widget(back)
        self.add_widget(layout)
    def _update_rect(self, i,v): self.rect.pos=i.pos; self.rect.size=i.size

# -------------------------- APP主入口 --------------------------
class AiradyMobileApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(BootScreen(name="boot"))
        sm.add_widget(DesktopScreen(name="desktop"))
        sm.add_widget(InfoScreen(name="info"))
        sm.add_widget(SystemScreen(name="system"))
        return sm

if __name__ == "__main__":
    AiradyMobileApp().run()