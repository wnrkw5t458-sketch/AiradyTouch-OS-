/*
 * Airady AEXE (Airady EXE) v0.1
 * 单文件自运行包，对标Windows EXE质感
 * 特点：无需安装，直接 ./xxx.aexe 运行
 * 命令：
 * ./airady_aexe build bin out.aexe      构建aexe包
 * ./airady_aexe info xxx.aexe           查看包信息
 * ./airady_aexe run xxx.aexe            运行aexe（等价直接./xxx.aexe）
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#define AEXE_MAGIC "AIRADYEXE"
#define MAGIC_LEN 9
#define NAME_MAX 64
#define VER_MAX 32
#define DESC_MAX 256
#define ICON_MAX 512

typedef struct {
    char magic[MAGIC_LEN];
    unsigned short fmt_ver;
    char name[NAME_MAX];
    char version[VER_MAX];
    char desc[DESC_MAX];
    char icon[ICON_MAX];
    long bin_size;
    char reserved[64];
} AexeHeader;

long get_file_size(FILE *fp) {
    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    return sz;
}

/* 构建 aexe 包 */
int aexe_build(const char *bin_src, const char *out_path) {
    FILE *fin = fopen(bin_src, "rb");
    if (!fin) {
        perror("open binary");
        return -1;
    }
    FILE *fout = fopen(out_path, "wb");
    if (!fout) {
        perror("create aexe");
        fclose(fin);
        return -1;
    }

    AexeHeader hdr;
    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, AEXE_MAGIC, MAGIC_LEN);
    hdr.fmt_ver = 1;

    printf("===== 构建 Airady EXE (.aexe) =====\n");
    printf("程序名称：");
    scanf("%s", hdr.name);
    printf("版本号：");
    scanf("%s", hdr.version);
    getchar();
    printf("程序描述：");
    fgets(hdr.desc, DESC_MAX, stdin);
    hdr.desc[strcspn(hdr.desc, "\n")] = 0;
    printf("输入ASCII图标（单行，终端显示，直接回车留空）：");
    fgets(hdr.icon, ICON_MAX, stdin);
    hdr.icon[strcspn(hdr.icon, "\n")] = 0;

    long bsize = get_file_size(fin);
    hdr.bin_size = bsize;

    // 写入头部
    fwrite(&hdr, sizeof(AexeHeader), 1, fout);

    // 写入程序二进制
    char buf[4096];
    long rd;
    while ((rd = fread(buf, 1, sizeof(buf), fin)) > 0) {
        fwrite(buf, 1, rd, fout);
    }
    fclose(fin);
    fclose(fout);
    chmod(out_path, 0755);
    printf("\n✅ 生成成功：%s\n", out_path);
    return 0;
}

/* 读取并校验头部 */
int aexe_read_header(const char *path, AexeHeader *hdr) {
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        perror("open aexe");
        return -1;
    }
    if (fread(hdr, sizeof(AexeHeader), 1, fp) != 1) {
        fclose(fp);
        return -2;
    }
    if (memcmp(hdr->magic, AEXE_MAGIC, MAGIC_LEN) != 0) {
        printf("❌ 不是合法的 Airady EXE (.aexe) 文件\n");
        fclose(fp);
        return -3;
    }
    fclose(fp);
    return 0;
}

/* 查看 aexe 信息 */
int aexe_info(const char *path) {
    AexeHeader hdr;
    int ret = aexe_read_header(path, &hdr);
    if (ret != 0) return ret;
    printf("\n===== Airady EXE 信息 =====\n");
    printf("名称：%s\n", hdr.name);
    printf("版本：%s\n", hdr.version);
    printf("描述：%s\n", hdr.desc);
    printf("图标行：%s\n", hdr.icon[0] ? hdr.icon : "(无)");
    printf("程序大小：%ld bytes\n", hdr.bin_size);
    printf("格式版本：%d\n", hdr.fmt_ver);
    printf("===========================\n");
    return 0;
}

/* 运行 aexe：提取内存中二进制，fork 执行 */
int aexe_run(const char *path) {
    AexeHeader hdr;
    int ret = aexe_read_header(path, &hdr);
    if (ret != 0) return ret;

    FILE *fp = fopen(path, "rb");
    fseek(fp, sizeof(AexeHeader), SEEK_SET);

    // 临时文件存放提取出的程序
    char tmpname[] = "/tmp/airady_aexe_XXXXXX";
    int fd = mkstemp(tmpname);
    if (fd < 0) {
        perror("mkstemp");
        fclose(fp);
        return -1;
    }
    FILE *ftmp = fdopen(fd, "wb");

    char buf[4096];
    long left = hdr.bin_size;
    long r;
    while (left > 0 && (r = fread(buf, 1, sizeof(buf), fp)) > 0) {
        fwrite(buf, 1, r, ftmp);
        left -= r;
    }
    fclose(ftmp);
    fclose(fp);
    chmod(tmpname, 0755);

    printf("🚀 启动 [%s] ...\n", hdr.name);
    pid_t pid = fork();
    if (pid == 0) {
        execl(tmpname, tmpname, (char *)NULL);
        exit(127);
    }
    wait(NULL);
    unlink(tmpname);
    return 0;
}

void help(void) {
    printf("Airady AEXE (Airady EXE) v0.1\n");
    printf("用法：\n");
    printf("  airady_aexe build <bin> <out.aexe>    构建Airady EXE包\n");
    printf("  airady_aexe info <xxx.aexe>            查看包元信息\n");
    printf("  airady_aexe run <xxx.aexe>             运行aexe程序\n");
    printf("  airady_aexe help                       帮助\n");
    printf("\n提示：直接 ./xxx.aexe 也可以运行！\n");
}

int main(int argc, char **argv) {
    if (argc < 2) {
        help();
        return 1;
    }
    if (strcmp(argv[1], "build") == 0) {
        if (argc < 4) {
            printf("参数不足：build 二进制文件 输出.aexe\n");
            return 1;
        }
        aexe_build(argv[2], argv[3]);
    } else if (strcmp(argv[1], "info") == 0) {
        if (argc < 3) {
            printf("参数不足：info xxx.aexe\n");
            return 1;
        }
        aexe_info(argv[2]);
    } else if (strcmp(argv[1], "run") == 0) {
        if (argc < 3) {
            printf("参数不足：run xxx.aexe\n");
            return 1;
        }
        aexe_run(argv[2]);
    } else if (strcmp(argv[1], "help") == 0) {
        help();
    } else {
        printf("未知命令\n");
        help();
        return 1;
    }
    return 0;
}