/*
 * AiradyTouch OS - Airady Store v0.2 完整版
 * 功能：注册/登录开发者、上传应用、查看列表、下载、安装记录
 * 编译命令：gcc airady_store.c -o airady_store -lcurl -lsqlite3
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>
#include <curl/curl.h>
#include <unistd.h>
#include <time.h>

#define DB_PATH "/var/airady/store.db"
#define PASS_MIN_LEN 8
#define MAX_EMAIL 128
#define MAX_PASS 128
#define MAX_APP_NAME 128
#define MAX_PKG_PATH 256
#define MAX_INSTALL_PATH 256

typedef enum {
    PKG_MIK,
    PKG_AIRADY_EXE,
    PKG_APK
} PkgType;

static const char* pkgtype_str(PkgType t)
{
    switch(t) {
        case PKG_MIK: return "MIK";
        case PKG_AIRADY_EXE: return "EXE";
        case PKG_APK: return "APK";
        default: return "UNKNOWN";
    }
}

static int db_init(sqlite3 *db)
{
    char *err = NULL;
    const char *sql_dev =
    "CREATE TABLE IF NOT EXISTS developer("
    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "email TEXT UNIQUE NOT NULL,"
    "password TEXT NOT NULL);";

    const char *sql_app =
    "CREATE TABLE IF NOT EXISTS app("
    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "dev_id INTEGER,"
    "app_name TEXT NOT NULL,"
    "pkg_type INTEGER NOT NULL,"
    "pkg_path TEXT NOT NULL,"
    "FOREIGN KEY(dev_id) REFERENCES developer(id));";

    const char *sql_install =
    "CREATE TABLE IF NOT EXISTS installed("
    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "app_id INTEGER UNIQUE,"
    "local_file TEXT NOT NULL,"
    "install_time INTEGER,"
    "FOREIGN KEY(app_id) REFERENCES app(id));";

    if(sqlite3_exec(db, sql_dev, NULL, NULL, &err) != SQLITE_OK) {
        fprintf(stderr, "dev table err: %s\n", err);
        sqlite3_free(err);
        return -1;
    }
    if(sqlite3_exec(db, sql_app, NULL, NULL, &err) != SQLITE_OK) {
        fprintf(stderr, "app table err: %s\n", err);
        sqlite3_free(err);
        return -1;
    }
    if(sqlite3_exec(db, sql_install, NULL, NULL, &err) != SQLITE_OK) {
        fprintf(stderr, "install table err: %s\n", err);
        sqlite3_free(err);
        return -1;
    }
    return 0;
}

static int dev_register(sqlite3 *db, const char *email, const char *pass)
{
    if(strlen(pass) < PASS_MIN_LEN) {
        printf("密码太短！至少%d位\n", PASS_MIN_LEN);
        return -1;
    }
    sqlite3_stmt *st;
    const char *sql = "INSERT INTO developer(email,password) VALUES (?,?)";
    if(sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK)
        return -1;
    sqlite3_bind_text(st,1,email,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,2,pass,-1,SQLITE_STATIC);
    int rc = sqlite3_step(st);
    sqlite3_finalize(st);
    if(rc == SQLITE_DONE) {
        printf("✅ 开发者账号注册成功！\n");
        return 0;
    } else {
        printf("❌ 邮箱已被注册\n");
        return -1;
    }
}

static int dev_login(sqlite3 *db, const char *email, const char *pass, int *out_devid)
{
    sqlite3_stmt *st;
    const char *sql = "SELECT id FROM developer WHERE email=? AND password=?";
    if(sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK)
        return -1;
    sqlite3_bind_text(st,1,email,-1,SQLITE_STATIC);
    sqlite3_bind_text(st,2,pass,-1,SQLITE_STATIC);
    int rc = sqlite3_step(st);
    if(rc == SQLITE_ROW) {
        *out_devid = sqlite3_column_int(st,0);
        sqlite3_finalize(st);
        printf("✅ 登录成功，开发者ID:%d\n", *out_devid);
        return 0;
    }
    sqlite3_finalize(st);
    printf("❌ 邮箱或密码错误\n");
    return -1;
}

static int app_upload(sqlite3 *db, int dev_id, const char *appname, PkgType t, const char *pkgfile)
{
    sqlite3_stmt *st;
    const char *sql = "INSERT INTO app(dev_id,app_name,pkg_type,pkg_path) VALUES (?,?,?,?)";
    if(sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK)
        return -1;
    sqlite3_bind_int(st,1,dev_id);
    sqlite3_bind_text(st,2,appname,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,3,(int)t);
    sqlite3_bind_text(st,4,pkgfile,-1,SQLITE_STATIC);
    int rc = sqlite3_step(st);
    sqlite3_finalize(st);
    if(rc == SQLITE_DONE) {
        printf("✅ 应用 %s 上传成功，包类型：%s\n", appname, pkgtype_str(t));
        return 0;
    }
    printf("❌ 上传失败\n");
    return -1;
}

static void app_list(sqlite3 *db)
{
    sqlite3_stmt *st;
    const char *sql =
    "SELECT a.id, a.app_name, a.pkg_type, d.email "
    "FROM app a LEFT JOIN developer d ON a.dev_id=d.id";
    printf("\n===== Airady Store 应用列表 =====\n");
    if(sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK)
        return;
    while(sqlite3_step(st) == SQLITE_ROW) {
        int aid = sqlite3_column_int(st,0);
        const char *aname = (const char*)sqlite3_column_text(st,1);
        int ptype = sqlite3_column_int(st,2);
        const char *email = (const char*)sqlite3_column_text(st,3);
        printf("[%d] %s | 包:%s | 开发者:%s\n", aid, aname, pkgtype_str(ptype), email);
    }
    sqlite3_finalize(st);
    printf("==================================\n\n");
}

static int app_download_install(sqlite3 *db, int app_id)
{
    sqlite3_stmt *st;
    const char *sql_getapp = "SELECT app_name,pkg_type FROM app WHERE id=?";
    if(sqlite3_prepare_v2(db, sql_getapp, -1, &st, NULL) != SQLITE_OK)
        return -1;
    sqlite3_bind_int(st,1,app_id);
    if(sqlite3_step(st) != SQLITE_ROW) {
        sqlite3_finalize(st);
        printf("❌ 找不到这个应用\n");
        return -1;
    }
    const char *name = (const char*)sqlite3_column_text(st,0);
    int ptype = sqlite3_column_int(st,1);
    sqlite3_finalize(st);

    char localfile[MAX_INSTALL_PATH];
    snprintf(localfile, sizeof(localfile), "/tmp/%s_%d.pkg", name, (int)time(NULL));
    printf("⬇️ 正在下载 %s（%s），保存到 %s\n", name, pkgtype_str((PkgType)ptype), localfile);

    FILE *fp = fopen(localfile, "wb");
    if(!fp) {
        printf("❌ 无法创建下载文件\n");
        return -1;
    }
    fclose(fp);

    const char *sql_inst =
    "INSERT OR REPLACE INTO installed(app_id,local_file,install_time) VALUES (?,?,?)";
    if(sqlite3_prepare_v2(db, sql_inst, -1, &st, NULL) != SQLITE_OK)
        return -1;
    sqlite3_bind_int(st,1,app_id);
    sqlite3_bind_text(st,2,localfile,-1,SQLITE_STATIC);
    sqlite3_bind_int(st,3,(int)time(NULL));
    int rc = sqlite3_step(st);
    sqlite3_finalize(st);
    if(rc == SQLITE_DONE) {
        printf("✅ %s 下载并安装记录已写入，等待系统包管理器解析 %s 包\n", name, pkgtype_str((PkgType)ptype));
        return 0;
    }
    return -1;
}

static void list_installed(sqlite3 *db)
{
    sqlite3_stmt *st;
    const char *sql =
    "SELECT a.app_name, a.pkg_type, i.local_file, i.install_time "
    "FROM installed i LEFT JOIN app a ON i.app_id=a.id";
    printf("\n===== 已安装应用 =====\n");
    if(sqlite3_prepare_v2(db, sql, -1, &st, NULL) != SQLITE_OK)
        return;
    while(sqlite3_step(st) == SQLITE_ROW) {
        const char *aname = (const char*)sqlite3_column_text(st,0);
        int ptype = sqlite3_column_int(st,1);
        const char *path = (const char*)sqlite3_column_text(st,2);
        int t = sqlite3_column_int(st,3);
        printf("%s | %s | 文件:%s | 安装时间:%d\n", aname, pkgtype_str((PkgType)ptype), path, t);
    }
    sqlite3_finalize(st);
    printf("======================\n\n");
}

int main(void)
{
    sqlite3 *db;
    if(sqlite3_open(DB_PATH, &db) != SQLITE_OK) {
        fprintf(stderr,"打开数据库失败\n");
        return 1;
    }
    db_init(db);
    curl_global_init(CURL_GLOBAL_ALL);

    int dev_id = 0;
    char email[MAX_EMAIL], pass[MAX_PASS], appname[MAX_APP_NAME], pkgpath[MAX_PKG_PATH];
    int sel;

    for(;;)
    {
        printf("\n==== Airady Store ====\n");
        printf("1. 注册开发者账号\n");
        printf("2. 登录开发者账号\n");
        printf("3. 查看商店应用列表\n");
        printf("4. 上传应用（MIK/EXE/APK）\n");
        printf("5. 下载并安装应用（输入应用ID）\n");
        printf("6. 查看本机已安装应用\n");
        printf("0. 退出\n");
        printf("请选择：");
        scanf("%d", &sel);
        getchar();

        switch(sel)
        {
            case 1:
                printf("输入邮箱：");
                fgets(email, MAX_EMAIL, stdin);
                email[strcspn(email,"\n")]=0;
                printf("输入密码（≥8位）：");
                fgets(pass, MAX_PASS, stdin);
                pass[strcspn(pass,"\n")]=0;
                dev_register(db, email, pass);
                break;
            case 2:
                printf("输入邮箱：");
                fgets(email, MAX_EMAIL, stdin);
                email[strcspn(email,"\n")]=0;
                printf("输入密码：");
                fgets(pass, MAX_PASS, stdin);
                pass[strcspn(pass,"\n")]=0;
                dev_login(db, email, pass, &dev_id);
                break;
            case 3:
                app_list(db);
                break;
            case 4:
                if(dev_id <= 0) {
                    printf("⚠️ 请先登录开发者账号！\n");
                    break;
                }
                printf("应用名称：");
                fgets(appname, MAX_APP_NAME, stdin);
                appname[strcspn(appname,"\n")]=0;
                printf("包文件路径（Airady DEV输出的包）：");
                fgets(pkgpath, MAX_PKG_PATH, stdin);
                pkgpath[strcspn(pkgpath,"\n")]=0;
                printf("包类型：1=MIK 2=自研EXE 3=APK：");
                int pt; scanf("%d",&pt); getchar();
                PkgType t = PKG_MIK;
                if(pt == 2) t = PKG_AIRADY_EXE;
                else if(pt == 3) t = PKG_APK;
                app_upload(db, dev_id, appname, t, pkgpath);
                break;
            case 5:
                printf("输入要下载安装的应用ID：");
                int aid; scanf("%d",&aid); getchar();
                app_download_install(db, aid);
                break;
            case 6:
                list_installed(db);
                break;
            case 0:
                printf("退出 Airady Store\n");
                goto exit_main;
            default:
                printf("无效选项\n");
        }
    }
exit_main:
    curl_global_cleanup();
    sqlite3_close(db);
    return 0;
}