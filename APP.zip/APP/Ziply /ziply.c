/*
 * AiradyTouch OS - Ziply v0.1
 * 解压工具，支持：ZIP / TAR / XZ / 7Z
 * 编译：gcc ziply.c -o ziply -larchive
 * 使用示例：
 * ./ziply extract test.tar.xz ./outdir
 * ./ziply extract app.7z ./outdir
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <archive.h>
#include <archive_entry.h>
#include <sys/stat.h>

#define MAX_PATH 512

static int make_dir(const char *path)
{
    struct stat st;
    if(stat(path, &st) == 0 && S_ISDIR(st.st_mode))
        return 0;
    return mkdir(path, 0755);
}

static int extract_archive(const char *archive_path, const char *dest_dir)
{
    struct archive *a;
    struct archive_entry *entry;
    int r;

    a = archive_read_new();
    archive_read_support_format_all(a);
    archive_read_support_filter_all(a);

    if(archive_read_open_filename(a, archive_path, 10240) != ARCHIVE_OK)
    {
        fprintf(stderr, "打开压缩包失败：%s\n", archive_error_string(a));
        archive_read_free(a);
        return -1;
    }

    printf("📂 Ziply 开始解压：%s → %s\n", archive_path, dest_dir);

    while((r = archive_read_next_header(a, &entry)) == ARCHIVE_OK)
    {
        char fullpath[MAX_PATH];
        snprintf(fullpath, MAX_PATH, "%s/%s", dest_dir, archive_entry_pathname(entry));

        // 创建目录
        if(archive_entry_filetype(entry) == AE_IFDIR)
        {
            make_dir(fullpath);
            continue;
        }
        // 父目录先建好
        char *last_slash = strrchr(fullpath, '/');
        if(last_slash)
        {
            *last_slash = 0;
            make_dir(fullpath);
            *last_slash = '/';
        }

        archive_entry_set_pathname(entry, fullpath);
        r = archive_read_extract(a, entry, ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM);
        if(r != ARCHIVE_OK)
        {
            fprintf(stderr, "⚠️ 文件提取警告：%s\n", archive_error_string(a));
        }
        printf("  %s\n", archive_entry_pathname(entry));
    }

    if(r != ARCHIVE_EOF)
    {
        fprintf(stderr, "❌ 解压出错：%s\n", archive_error_string(a));
        archive_read_close(a);
        archive_read_free(a);
        return -1;
    }

    archive_read_close(a);
    archive_read_free(a);
    printf("✅ Ziply 解压完成！\n");
    return 0;
}

static void help(void)
{
    printf("==== Ziply 解压工具 ====\n");
    printf("用法：\n");
    printf("  ./ziply extract 压缩包路径 输出目录\n");
    printf("支持格式：zip tar xz 7z gz bz2\n");
    printf("示例：\n");
    printf("  ./ziply extract package.7z ./output\n");
    printf("  ./ziply extract data.zip ./out\n");
}

int main(int argc, char **argv)
{
    if(argc < 4)
    {
        help();
        return 1;
    }
    if(strcmp(argv[1], "extract") != 0)
    {
        help();
        return 1;
    }
    const char *pkg = argv[2];
    const char *out = argv[3];
    make_dir(out);
    return extract_archive(pkg, out);
}