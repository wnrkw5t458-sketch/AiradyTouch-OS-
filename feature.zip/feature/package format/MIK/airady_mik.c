/*
 * Airady MIK Package Manager v0.1
 * .mik 安装包工具（对标APK质感，AiradyTouch OS专属）
 * 编译：gcc airady_mik.c -o airady_mik
 *
 * 命令：
 *  ./airady_mik pack <bin> <out.mik>       # 打包二进制为mik安装包
 *  ./airady_mik install xxx.mik            # 安装mik包到系统
 *  ./airady_mik run <pkgname>              # 运行已安装软件
 *  ./airady_mik list                       # 列出全部已安装MIK软件
 *  ./airady_mik uninstall <pkgname>        # 卸载
 *  ./airady_mik info xxx.mik               # 查看mik包信息
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#define MIK_MAGIC "AIRADYMIK"
#define MAGIC_LEN 8
#define PKG_NAME_MAX 64
#define VER_MAX 32
#define DESC_MAX 256
#define CMD_MAX 256
#define DEP_MAX 256
#define INSTALL_ROOT "./mik_packages/"
#define META_SUFFIX ".meta"

// MIK 文件头部结构
typedef struct {
    char magic[MAGIC_LEN];
    unsigned short fmt_ver;
    char pkg_name[PKG_NAME_MAX];
    char version[VER_MAX];
    char desc[DESC_MAX];
    char run_cmd[CMD_MAX];
    char depends[DEP_MAX];
    long bin_size;
    char reserved[64];
} MikHeader;

// 安全创建目录
int mkpath(const char *path) {
    char tmp[512];
    char *p;
    strncpy(tmp, path, sizeof(tmp)-1);
    for(p = tmp + 1; *p; p++) {
        if(*p == '/') {
            *p = 0;
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    mkdir(tmp, 0755);
    return 0;
}

// 读取文件大小
long get_file_size(FILE *fp) {
    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    return sz;
}

// 打包：二进制 → .mik
int mik_pack(const char *bin_path, const char *out_mik) {
    FILE *fin = fopen(bin_path, "rb");
    if(!fin) {
        perror("open bin");
        return -1;
    }
    FILE *fout = fopen(out_mik, "wb");
    if(!fout) {
        perror("create mik");
        fclose(fin);
        return -1;
    }

    MikHeader hdr;
    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, MIK_MAGIC, MAGIC_LEN);
    hdr.fmt_ver = 1;

    printf("=== 打包 MIK 安装包 ===\n");
    printf("输入包名：");
    scanf("%s", hdr.pkg_name);
    printf("输入软件版本：");
    scanf("%s", hdr.version);
    getchar();
    printf("输入软件描述：");
    fgets(hdr.desc, DESC_MAX, stdin);
    hdr.desc[strcspn(hdr.desc, "\n")] = 0;
    printf("输入安装后启动命令（例 ./%s）：", hdr.pkg_name);
    fgets(hdr.run_cmd, CMD_MAX, stdin);
    hdr.run_cmd[strcspn(hdr.run_cmd, "\n")] = 0;
    printf("输入依赖包，多个用逗号隔开，无依赖直接回车：");
    fgets(hdr.depends, DEP_MAX, stdin);
    hdr.depends[strcspn(hdr.depends, "\n")] = 0;

    long fsz = get_file_size(fin);
    hdr.bin_size = fsz;

    // 写入头部
    fwrite(&hdr, sizeof(MikHeader), 1, fout);
    // 写入二进制数据
    char buf[4096];
    long read_cnt;
    while((read_cnt = fread(buf,1,sizeof(buf),fin)) > 0) {
        fwrite(buf, 1, read_cnt, fout);
    }
    fclose(fin);
    fclose(fout);
    printf("\n✅ 打包成功：%s\n", out_mik);
    return 0;
}

// 校验并读取mik头部
int mik_read_header(const char *mikfile, MikHeader *hdr) {
    FILE *fp = fopen(mikfile, "rb");
    if(!fp) {
        perror("open mik");
        return -1;
    }
    if(fread(hdr, sizeof(MikHeader),1,fp) != 1) {
        fclose(fp);
        return -2;
    }
    if(memcmp(hdr->magic, MIK_MAGIC, MAGIC_LEN) != 0) {
        printf("❌ 不是合法的 MIK 安装包！\n");
        fclose(fp);
        return -3;
    }
    fclose(fp);
    return 0;
}

// 查看包信息
int mik_info(const char *mikfile) {
    MikHeader hdr;
    int ret = mik_read_header(mikfile, &hdr);
    if(ret != 0) return ret;
    printf("\n===== MIK 包信息 =====\n");
    printf("包名：%s\n", hdr.pkg_name);
    printf("版本：%s\n", hdr.version);
    printf("描述：%s\n", hdr.desc);
    printf("启动命令：%s\n", hdr.run_cmd);
    printf("依赖：%s\n", hdr.depends[0]?hdr.depends:"无");
    printf("二进制大小：%ld bytes\n", hdr.bin_size);
    printf("格式版本：%d\n", hdr.fmt_ver);
    printf("======================\n");
    return 0;
}

// 安装mik包
int mik_install(const char *mikfile) {
    MikHeader hdr;
    int ret = mik_read_header(mikfile, &hdr);
    if(ret !=0) return ret;

    char pkg_dir[512];
    snprintf(pkg_dir, sizeof(pkg_dir), "%s%s/", INSTALL_ROOT, hdr.pkg_name);
    mkpath(pkg_dir);

    FILE *fin = fopen(mikfile, "rb");
    fseek(fin, sizeof(MikHeader), SEEK_SET);
    char bin_path[512];
    snprintf(bin_path, sizeof(bin_path), "%s%s", pkg_dir, hdr.pkg_name);
    FILE *fbin = fopen(bin_path, "wb");

    char buf[4096];
    long left = hdr.bin_size;
    long r;
    while(left > 0 && (r = fread(buf,1,sizeof(buf),fin))>0) {
        fwrite(buf,1,r,fbin);
        left -= r;
    }
    fclose(fin);
    fclose(fbin);
    chmod(bin_path, 0755);

    // 写入元数据文件
    char meta_path[512];
    snprintf(meta_path, sizeof(meta_path), "%s%s%s", pkg_dir, hdr.pkg_name, META_SUFFIX);
    FILE *fmeta = fopen(meta_path, "w");
    fprintf(fmeta, "name=%s\nver=%s\ndesc=%s\nrun=%s\ndep=%s\n",
        hdr.pkg_name, hdr.version, hdr.desc, hdr.run_cmd, hdr.depends);
    fclose(fmeta);

    printf("✅ 安装完成：%s\n", hdr.pkg_name);
    printf("📍安装目录：%s\n", pkg_dir);
    return 0;
}

// 运行已安装包
int mik_run(const char *pkgname) {
    char pkg_dir[512];
    snprintf(pkg_dir, sizeof(pkg_dir), "%s%s/", INSTALL_ROOT, pkgname);
    char bin_path[512];
    snprintf(bin_path, sizeof(bin_path), "%s%s", pkg_dir, pkgname);
    struct stat st;
    if(stat(bin_path, &st) !=0) {
        printf("❌ 软件 %s 未安装\n", pkgname);
        return -1;
    }
    printf("🚀 启动 %s ...\n", pkgname);
    pid_t pid = fork();
    if(pid ==0) {
        execl(bin_path, bin_path, (char*)NULL);
        exit(127);
    }
    return 0;
}

// 列出所有安装包
int mik_list(void) {
    DIR *d = opendir(INSTALL_ROOT);
    if(!d) {
        printf("📦 没有已安装的MIK软件\n");
        return 0;
    }
    printf("\n===== 已安装 MIK 软件列表 =====\n");
    struct dirent *ent;
    while((ent = readdir(d)) != NULL) {
        if(ent->d_type == DT_DIR && ent->d_name[0] != '.') {
            printf(" • %s\n", ent->d_name);
        }
    }
    closedir(d);
    printf("===============================\n");
    return 0;
}

// 卸载包（简单删除目录）
int mik_uninstall(const char *pkgname) {
    char pkg_dir[512];
    snprintf(pkg_dir, sizeof(pkg_dir), "%s%s/", INSTALL_ROOT, pkgname);
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "rm -rf %s", pkg_dir);
    printf("🗑️ 卸载 %s ...\n", pkgname);
    system(cmd);
    printf("✅ 卸载完成\n");
    return 0;
}

void help(void) {
    printf("Airady MIK Package Manager v0.1\n");
    printf("用法：\n");
    printf("  airady_mik pack <bin> <output.mik>    打包二进制为MIK安装包\n");
    printf("  airady_mik install xxx.mik           安装MIK包\n");
    printf("  airady_mik run <pkgname>             运行已安装软件\n");
    printf("  airady_mik list                      列出所有安装包\n");
    printf("  airady_mik uninstall <pkgname>       卸载软件\n");
    printf("  airady_mik info xxx.mik              查看MIK包详情\n");
    printf("  airady_mik help                      帮助\n");
}

int main(int argc, char **argv) {
    if(argc < 2) {
        help();
        return 1;
    }
    if(strcmp(argv[1], "pack") == 0) {
        if(argc <4) { printf("用法：pack bin out.mik\n"); return 1; }
        mik_pack(argv[2], argv[3]);
    } else if(strcmp(argv[1], "install") ==0) {
        if(argc <3) { printf("用法：install xxx.mik\n"); return1; }
        mik_install(argv[2]);
    } else if(strcmp(argv[1], "run") ==0) {
        if(argc <3) { printf("用法：run pkgname\n"); return1; }
        mik_run(argv[2]);
    } else if(strcmp(argv[1], "list") ==0) {
        mik_list();
    } else if(strcmp(argv[1], "uninstall") ==0) {
        if(argc <3) { printf("用法：uninstall pkgname\n"); return1; }
        mik_uninstall(argv[2]);
    } else if(strcmp(argv[1], "info") ==0) {
        if(argc <3) { printf("用法：info xxx.mik\n"); return1; }
        mik_info(argv[2]);
    } else if(strcmp(argv[1], "help") ==0) {
        help();
    } else {
        printf("未知命令\n");
        help();
        return 1;
    }
    return 0;
}

