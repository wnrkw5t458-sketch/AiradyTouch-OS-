/*
 * AiradyTouch OS - Airady Editor v0.1
 * 命令行简易文本编辑器
 * 编译：gcc airady_editor.c -o airady_editor
 * 运行：./airady_editor [文件名]
 * 命令：
 *   list        列出全部行
 *   add 文本    在末尾添加一行
 *   del 行号    删除指定行
 *   set N 文本  修改第N行
 *   save        保存文件
 *   quit        退出编辑器
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINES 256
#define MAX_LINE_LEN 512

char lines[MAX_LINES][MAX_LINE_LEN];
int line_count = 0;
char filename[256] = {0};

static void load_file(const char *fname)
{
    FILE *f = fopen(fname, "r");
    if (!f)
    {
        printf("📄 文件不存在，新建文件：%s\n", fname);
        strncpy(filename, fname, sizeof(filename)-1);
        return;
    }
    strncpy(filename, fname, sizeof(filename)-1);
    line_count = 0;
    while (fgets(lines[line_count], MAX_LINE_LEN, f) && line_count < MAX_LINES)
    {
        // 去掉末尾换行符
        size_t l = strlen(lines[line_count]);
        if (l>0 && lines[line_count][l-1] == '\n')
            lines[line_count][l-1] = 0;
        line_count++;
    }
    fclose(f);
    printf("✅ 载入文件 %s，共 %d 行\n", filename, line_count);
}

static void save_file(void)
{
    if (strlen(filename) == 0)
    {
        printf("❌ 没有设置文件名！\n");
        return;
    }
    FILE *f = fopen(filename, "w");
    if (!f)
    {
        printf("❌ 无法写入文件\n");
        return;
    }
    for(int i=0; i<line_count; i++)
    {
        fprintf(f, "%s\n", lines[i]);
    }
    fclose(f);
    printf("💾 保存成功：%s\n", filename);
}

static void list_lines(void)
{
    printf("\n==== 文件内容 (%d行) ====\n", line_count);
    for(int i=0; i<line_count; i++)
    {
        printf("%3d | %s\n", i+1, lines[i]);
    }
    printf("========================\n");
}

static void add_line(const char *text)
{
    if (line_count >= MAX_LINES)
    {
        printf("❌ 行数已满，最多%d行\n", MAX_LINES);
        return;
    }
    strncpy(lines[line_count], text, MAX_LINE_LEN-1);
    line_count++;
    printf("➕ 已添加一行\n");
}

static void del_line(int num)
{
    if(num < 1 || num > line_count)
    {
        printf("❌ 行号无效！范围 1~%d\n", line_count);
        return;
    }
    int idx = num - 1;
    for(int i=idx; i<line_count-1; i++)
    {
        strcpy(lines[i], lines[i+1]);
    }
    line_count--;
    printf("🗑️ 删除第 %d 行\n", num);
}

static void set_line(int num, const char *text)
{
    if(num <1 || num > line_count)
    {
        printf("❌ 行号无效！范围 1~%d\n", line_count);
        return;
    }
    strncpy(lines[num-1], text, MAX_LINE_LEN-1);
    printf("✏️ 修改第 %d 行\n", num);
}

static void help(void)
{
    printf("\n==== Airady Editor 帮助 ====\n");
    printf("list                查看全部行\n");
    printf("add 文字            添加一行\n");
    printf("del N               删除第N行\n");
    printf("set N 文字          修改第N行\n");
    printf("save                保存文件\n");
    printf("quit                退出编辑器\n");
    printf("help                显示帮助\n");
    printf("============================\n");
}

static void parse_cmd(char *buf)
{
    char cmd[64];
    if(sscanf(buf, "%s", cmd) != 1) return;

    if(strcmp(cmd, "help") == 0)
    {
        help();
    }
    else if(strcmp(cmd, "list") ==0)
    {
        list_lines();
    }
    else if(strcmp(cmd, "save") ==0)
    {
        save_file();
    }
    else if(strcmp(cmd, "quit") ==0)
    {
        printf("👋 退出编辑器\n");
        exit(0);
    }
    else if(strcmp(cmd, "add") ==0)
    {
        char *p = buf + 4;
        while(*p == ' ') p++;
        add_line(p);
    }
    else if(strcmp(cmd, "del") ==0)
    {
        int n;
        if(sscanf(buf+4, "%d", &n) ==1)
            del_line(n);
        else printf("❌ del 需要行号\n");
    }
    else if(strcmp(cmd, "set") ==0)
    {
        int n;
        char text[MAX_LINE_LEN];
        if(sscanf(buf+4, "%d %[^\n]", &n, text) ==2)
            set_line(n, text);
        else printf("❌ set 格式：set 3 这是新内容\n");
    }
    else
    {
        printf("❌ 未知命令，help查看指令\n");
    }
}

int main(int argc, char** argv)
{
    printf("=====================================\n");
    printf("      Airady Editor v0.1             \n");
    printf("=====================================\n");
    if(argc >=2)
    {
        load_file(argv[1]);
    }
    else
    {
        printf("📝 新建空白文档，save前请记得保存\n");
    }
    char buf[MAX_LINE_LEN];
    for(;;)
    {
        printf("editor> ");
        if(!fgets(buf, MAX_LINE_LEN, stdin)) break;
        // 去掉换行
        size_t l = strlen(buf);
        if(l>0 && buf[l-1] == '\n') buf[l-1]=0;
        parse_cmd(buf);
    }
    return 0;
}