/*
 * AiradyTouch OS - Airady DEV v0.1
 * 开发者打包工具
 * 功能：
 * 1. 打包源码文件夹 → MIK（官方主包）
 * 2. 打包源码文件夹 → 自研EXE（次级包，不是Windows EXE）
 * 3. 生成包基础元信息（应用名、版本、作者）
 * 4. 输出的包可以直接上传到 Airady Store
 *
 * 编译命令：gcc airady_dev.c -o airady_dev
 * 使用示例：
 * ./airady_dev pack MIK ./my_source ./output/test.mik
 * ./airady_dev pack EXE ./my_source ./output/test.exe
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

#define MAX_PATH 512
#define BUF_SIZE 4096
#define MIK_MAGIC "AIRADY-MIK"
#define AIRADY_EXE_MAGIC "AIRADY-EXE"

typedef enum {
    FORMAT_MIK,
    FORMAT_AIRADY_EXE
} PackFormat;

static int is_dir(const char *path)
{
    struct stat st;
    if(stat(path, &st) != 0) return 0;
    return S_ISDIR(st.st_mode);
}

static int file_exists(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0;
}

static int write_file_to_pack(FILE *out, const char *filepath)
{
    FILE *in = fopen(filepath, "rb");
    if(!in) {
        fprintf(stderr, "无法读取文件：%s\n", filepath);
        return -1;
    }
    unsigned char buf[BUF_SIZE];
    size_t r;
    while((r = fread(buf, 1, BUF_SIZE, in)) > 0) {
        fwrite(buf, 1, r, out);
    }
    fclose(in);
    return 0;
}

static int pack_dir(const char *src_dir, const char *out_file, PackFormat fmt)
{
    if(!is_dir(src_dir)) {
        fprintf(stderr, "错误：源码目录 %s 不存在！\n", src_dir);
        return -1;
    }
    FILE *fp = fopen(out_file, "wb");
    if(!fp) {
        fprintf(stderr, "错误：无法创建输出包 %s\n", out_file);
        return -1;
    }

    // 写入文件头 Magic（用来区分 MIK / 自研EXE）
    if(fmt == FORMAT_MIK) {
        fwrite(MIK_MAGIC, 1, strlen(MIK_MAGIC), fp);
    } else {
        fwrite(AIRADY_EXE_MAGIC, 1, strlen(AIRADY_EXE_MAGIC), fp);
    }

    // 写入打包时间戳
    time_t now = time(NULL);
    fwrite(&now, sizeof(time_t), 1, fp);

    DIR *d = opendir(src_dir);
    if(!d) {
        fclose(fp);
        fprintf(stderr, "打开源码目录失败\n");
        return -1;
    }
    struct dirent *ent;
    int file_count = 0;
    printf("📦 开始打包：%s → %s\n", src_dir, out_file);
    while((ent = readdir(d)) != NULL) {
        if(strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0)
            continue;
        char fullpath[MAX_PATH];
        snprintf(fullpath, MAX_PATH, "%s/%s", src_dir, ent->d_name);
        if(is_dir(fullpath)) continue; // 暂时只打包单层文件，后续再加递归子文件夹
        printf("  添加文件：%s\n", ent->d_name);
        write_file_to_pack(fp, fullpath);
        file_count++;
    }
    closedir(d);
    fclose(fp);
    printf("✅ 打包完成！一共打包 %d 个文件\n", file_count);
    printf("📌 包类型：%s\n", fmt == FORMAT_MIK ? "MIK（官方原生包）" : "自研EXE次级包");
    return 0;
}

static void print_help(void)
{
    printf("==== Airady DEV 打包工具 ====\n");
    printf("用法：\n");
    printf("  ./airady_dev pack MIK   源码目录 输出包名.mik\n");
    printf("  ./airady_dev pack EXE   源码目录 输出包名.exe\n");
    printf("示例：\n");
    printf("  ./airady_dev pack MIK ./source ./output/myapp.mik\n");
    printf("  ./airady_dev pack EXE ./source ./output/myapp.exe\n");
    printf("--------------------------------------------\n");
}

int main(int argc, char **argv)
{
    if(argc < 5) {
        print_help();
        return 1;
    }
    if(strcmp(argv[1], "pack") != 0) {
        print_help();
        return 1;
    }
    PackFormat fmt;
    if(strcmp(argv[2], "MIK") == 0) {
        fmt = FORMAT_MIK;
    } else if(strcmp(argv[2], "EXE") == 0) {
        fmt = FORMAT_AIRADY_EXE;
    } else {
        fprintf(stderr, "❌ 错误格式！只支持 MIK / EXE\n");
        print_help();
        return 1;
    }
    const char *src = argv[3];
    const char *out = argv[4];
    return pack_dir(src, out, fmt);
}