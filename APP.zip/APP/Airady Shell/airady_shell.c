/*
 * AiradyTouch OS - Airady Shell v0.1
 * 系统交互式终端外壳
 * 编译：gcc airady_shell.c -o airady_shell
 * 内置命令：cd ls pwd clear exit help
 * 可直接调用：airady_dev / airady_pkg / ziply / airady_store
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>

#define MAX_LINE 1024
#define MAX_ARGS 64
#define PROMPT "airady $ "

static void split_args(char *line, char **argv, int *argc_out)
{
    *argc_out = 0;
    char *tok = strtok(line, " \t\n");
    while (tok != NULL && *argc_out < MAX_ARGS -1)
    {
        argv[(*argc_out)++] = tok;
        tok = strtok(NULL, " \t\n");
    }
    argv[*argc_out] = NULL;
}

static int builtin_cmd(char **argv, int argc)
{
    if (argc == 0) return 1;

    if (strcmp(argv[0], "exit") == 0)
    {
        printf("👋 退出 Airady Shell\n");
        exit(0);
    }
    if (strcmp(argv[0], "pwd") == 0)
    {
        char buf[512];
        getcwd(buf, sizeof(buf));
        printf("%s\n", buf);
        return 0;
    }
    if (strcmp(argv[0], "cd") == 0)
    {
        const char *target = argc >=2 ? argv[1] : getenv("HOME");
        if (chdir(target) != 0)
        {
            perror("cd");
        }
        return 0;
    }
    if (strcmp(argv[0], "clear") == 0)
    {
        printf("\033[H\033[J");
        return 0;
    }
    if (strcmp(argv[0], "help") == 0)
    {
        printf("==== Airady Shell 帮助 ====\n");
        printf("内置命令：cd  ls  pwd  clear  exit  help\n");
        printf("系统工具：\n");
        printf("  airady_dev    打包 MIK / EXE\n");
        printf("  airady_pkg    包安装器\n");
        printf("  airady_store  应用商店\n");
        printf("  ziply         解压工具\n");
        printf("===========================\n");
        return 0;
    }
    return -1;
}

static void run_external(char **argv)
{
    pid_t pid = fork();
    if (pid < 0)
    {
        perror("fork");
        return;
    }
    if (pid == 0)
    {
        execvp(argv[0], argv);
        perror(argv[0]);
        exit(1);
    }
    int w;
    waitpid(pid, &w, 0);
}

int main(void)
{
    char line[MAX_LINE];
    char *argv[MAX_ARGS];
    int argc;

    printf("=====================================\n");
    printf("   Welcome to AiradyTouch OS Shell   \n");
    printf("=====================================\n");
    printf("输入 help 查看命令列表\n");

    for(;;)
    {
        printf("%s", PROMPT);
        if (fgets(line, MAX_LINE, stdin) == NULL)
        {
            printf("\n");
            break;
        }
        split_args(line, argv, &argc);
        int b = builtin_cmd(argv, argc);
        if (b == -1)
        {
            run_external(argv);
        }
    }
    return 0;
}