/*
 * AiradyTouch OS - Airady Point IO v0.1
 * 底层IO调试控制台【压轴组件】
 * 编译：gcc airady_io.c -o airady_io
 * 运行：./airady_io
 * 命令列表：
 *   memdump 地址 长度       查看内存十六进制
 *   memset 地址 值          写入内存字节
 *   hexdump 文件路径        文件十六进制查看
 *   readb 文件 偏移         读取文件单字节
 *   writeb 文件 偏移 值     在文件指定偏移写入字节
 *   info                    IO系统信息
 *   clear                   清屏
 *   exit                    退出
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>

#define MAX_BUF 512
#define LINE_WIDTH 16

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;

static void banner(void)
{
    printf("\n=====================================\n");
    printf("      Airady Point IO v0.1           \n");
    printf("    Low-level IO Debug Console       \n");
    printf("=====================================\n");
    printf("输入 help 查看全部调试命令\n");
}

static void help(void)
{
    printf("\n==== Airady Point IO 命令 ====\n");
    printf("memdump addr len        内存HEX转储（addr=十进制）\n");
    printf("memset addr byte        向内存地址写入单字节(0~255)\n");
    printf("hexdump path            文件十六进制查看\n");
    printf("readb path off          读取文件偏移处1字节\n");
    printf("writeb path off val     文件偏移写入1字节\n");
    printf("info                    IO子系统信息\n");
    printf("clear                   清屏\n");
    printf("exit                    退出Point IO\n");
    printf("==============================\n");
}

static void do_info(void)
{
    printf("\n📡 Airady Point IO 信息\n");
    printf("模式：用户态调试IO控制台\n");
    printf("位宽：8/16/32字节操作支持\n");
    printf("能力：内存调试、原始文件二进制访问\n");
    printf("注意：用户空间无法直接访问硬件物理端口（模拟）\n");
}

static void do_clear(void)
{
    printf("\033[H\033[J");
}

// 内存dump（使用一块本地缓冲区模拟目标内存区域）
static u8 sim_mem[4096];
static void do_memdump(u32 addr, u32 len)
{
    if (addr >= sizeof(sim_mem))
    {
        printf("❌ 地址超出模拟内存范围(0~%zu)\n", sizeof(sim_mem)-1);
        return;
    }
    u32 end = addr + len;
    if (end > sizeof(sim_mem)) end = sizeof(sim_mem);
    printf("\n--- Memory Dump 0x%04X ~ 0x%04X ---\n", addr, end-1);
    for(u32 i = addr; i < end; i += LINE_WIDTH)
    {
        printf("%04X: ", i);
        for(u32 j = i; j < i+LINE_WIDTH && j < end; j++)
        {
            printf("%02X ", sim_mem[j]);
        }
        printf(" | ");
        for(u32 j = i; j < i+LINE_WIDTH && j < end; j++)
        {
            u8 c = sim_mem[j];
            if(c >= 0x20 && c <= 0x7E) putchar(c);
            else putchar('.');
        }
        putchar('\n');
    }
}

static void do_memset(u32 addr, u8 val)
{
    if (addr >= sizeof(sim_mem))
    {
        printf("❌ 地址超出模拟内存范围\n");
        return;
    }
    sim_mem[addr] = val;
    printf("✅ 0x%04X = 0x%02X\n", addr, val);
}

static void do_hexdump(const char *path)
{
    FILE *f = fopen(path, "rb");
    if(!f)
    {
        perror("hexdump open");
        return;
    }
    uint32_t off = 0;
    u8 buf[LINE_WIDTH];
    size_t r;
    printf("\n--- Hexdump: %s ---\n", path);
    while((r = fread(buf,1,LINE_WIDTH,f)) >0)
    {
        printf("%04X: ", off);
        for(size_t i=0;i<LINE_WIDTH;i++)
        {
            if(i < r) printf("%02X ", buf[i]);
            else printf("   ");
        }
        printf(" | ");
        for(size_t i=0;i<r;i++)
        {
            u8 c = buf[i];
            if(c >=0x20 && c <=0x7E) putchar(c);
            else putchar('.');
        }
        putchar('\n');
        off += LINE_WIDTH;
    }
    fclose(f);
}

static void do_readb(const char *path, u32 off)
{
    FILE *f = fopen(path, "rb");
    if(!f) { perror("readb open"); return; }
    if(fseek(f, off, SEEK_SET) !=0) { perror("fseek"); fclose(f); return; }
    u8 b;
    if(fread(&b,1,1,f) !=1)
    {
        printf("❌ 偏移处无数据\n");
        fclose(f);
        return;
    }
    printf("readb @%u = 0x%02X (%d, '%c')\n", off, b, b, (b>=0x20&&b<=0x7E)?b:'.');
    fclose(f);
}

static void do_writeb(const char *path, u32 off, u8 val)
{
    FILE *f = fopen(path, "r+b");
    if(!f) { perror("writeb open"); return; }
    if(fseek(f, off, SEEK_SET) !=0) { perror("fseek"); fclose(f); return; }
    if(fwrite(&val,1,1,f) !=1)
    {
        printf("❌ 写入失败\n");
        fclose(f);
        return;
    }
    fclose(f);
    printf("✅ writeb @%u = 0x%02X\n", off, val);
}

static void parse_line(char *line)
{
    char cmd[64];
    if(sscanf(line, "%s", cmd) != 1) return;

    if(strcmp(cmd, "help") ==0)
    {
        help();
    }
    else if(strcmp(cmd, "info") ==0)
    {
        do_info();
    }
    else if(strcmp(cmd, "clear") ==0)
    {
        do_clear();
    }
    else if(strcmp(cmd, "exit") ==0)
    {
        printf("\n👋 关闭 Airady Point IO\n");
        exit(0);
    }
    else if(strcmp(cmd, "memdump") ==0)
    {
        u32 a,l;
        if(sscanf(line+7, "%u %u", &a, &l) ==2)
            do_memdump(a,l);
        else printf("用法：memdump 地址 长度\n");
    }
    else if(strcmp(cmd, "memset") ==0)
    {
        u32 a; int v;
        if(sscanf(line+6, "%u %d", &a, &v) ==2 && v>=0 && v<=255)
            do_memset(a, (u8)v);
        else printf("用法：memset 地址 字节值(0-255)\n");
    }
    else if(strcmp(cmd, "hexdump") ==0)
    {
        char path[MAX_BUF];
        if(sscanf(line+8, "%[^\n]", path) ==1)
            do_hexdump(path);
        else printf("用法：hexdump 文件路径\n");
    }
    else if(strcmp(cmd, "readb") ==0)
    {
        char path[MAX_BUF]; u32 o;
        if(sscanf(line+6, "%s %u", path, &o) ==2)
            do_readb(path, o);
        else printf("用法：readb 文件 偏移\n");
    }
    else if(strcmp(cmd, "writeb") ==0)
    {
        char path[MAX_BUF]; u32 o; int v;
        if(sscanf(line+7, "%s %u %d", path, &o, &v)==2 && v>=0 && v<=255)
            do_writeb(path, o, (u8)v);
        else printf("用法：writeb 文件 偏移 值(0-255)\n");
    }
    else
    {
        printf("❌ 未知指令，输入 help\n");
    }
}

int main(void)
{
    // 初始化模拟内存为0
    memset(sim_mem, 0, sizeof(sim_mem));
    banner();
    char line[MAX_BUF];
    for(;;)
    {
        printf("io> ");
        if(!fgets(line, MAX_BUF, stdin)) break;
        size_t ln = strlen(line);
        if(ln>0 && line[ln-1] == '\n') line[ln-1]=0;
        parse_line(line);
    }
    return 0;
}